$(function(){
    function PreviewItemConfig(el){
        var $el = $(el);
        var configData = JSON.parse($el.data('config'));
        

    }
})