/*
*
* Booking JS
* @ThemeEaster
*/

$(function () {
	function addBookingForm(form) {
		// Get the form.
		
		// Get the messages div.
		var formMessages = form.find('.b-form-messages');

		// Set up an event listener for the contact form.
		$(form).submit(function (event) {
			// Stop the browser from submitting the form.
			event.preventDefault();
			try {

				// Serialize the form data.
				var formData = $(form).serialize();
				// Submit the form using AJAX.
				var b_person = form.find('.b_person').val();
				var email = form.find('.b_email').val();
				var phone = form.find('.b_phone').val();
				var b_date = form.find('.b_date').val();
				var b_message = form.find('.b_message').val();
				var errs = [];

				if (!phone) {
					errs.push("Số diện thoại");
				}
				if (!email) {
					errs.push("Email");
				}
				if (b_person < 1) {
					errs.push("Bao nhiêu ngưởi")
				}
				if (!b_date) {
					errs.push("Thời gian đặt bàn")
				}
				if (errs.length) {
					// Make sure that the formMessages div has the 'error' class.

					$(formMessages).removeClass('alert-success');
					$(formMessages).addClass('alert-danger');
					$(formMessages).html("Hãy chắc chán rằng các thông tin sau hợp lệ: <br />" + errs.join(", "));
					return false;
				}

				var data = {
					name: form.find('.b_name').val(),
					email: email,
					phone_number: phone,
					message: b_message,
					quantity: b_person,
					booking_time: b_date
				}
				data.title = data.name + " muốn đặt bàn ăn cho " + b_person + " người";

				$.ajax({
					type: 'POST',
					url: form.attr('action'),
					data: data
				})
					.done(function (response) {
						// Make sure that the formMessages div has the 'success' class.
						$(formMessages).removeClass('alert-danger');
						$(formMessages).addClass('alert-success');

						// Set the message text.
						$(formMessages).text(response.message);

						// Clear the form.
						form.find('.b_name').val('');
						form.find('.b_email').val('');
						form.find('.b_phone').val('');
						form.find('.b_person').val('');
						form.find('.b_date').val('');
						form.find('.b_message').val('');
					})
					.fail(function (data) {
						// Make sure that the formMessages div has the 'error' class.
						$(formMessages).removeClass('alert-success');
						$(formMessages).addClass('alert-danger');

						// Set the message text.
						if (data.responseText !== '') {
							$(formMessages).text(data.responseText);
						} else {
							$(formMessages).text('Oops! An error occured and your request could not be complete.');
						}
					});

			} catch (error) {
				console.log(error);
			}
		});

	}

	$('.ajax_booking_form').each(function(i, f){
		addBookingForm($(f));
	})
	$('.datepicker-group').each(function (i, e) {
		var $d = $(e);
		var format = $d.data('format') || 'dd/mm/yyyy';
		$d.datepicker({
			format: format
		});
	})

});
