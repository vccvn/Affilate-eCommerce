
(function($){ "use strict";

$('.subscribe-popup').each(function(i, e){
    var $popup = $(e);
    var countdown = parseInt($popup.data('countdown')) || 0;
    var frequency = $popup.data('frequency');
    if(isNaN(countdown) || countdown == Infinity || countdown < 0) countdown = 0;
    if((frequency == 'always' ) || (frequency == 'sometimes' && data.session.today == 1) || (frequency == 'first' && data.cookie.total == 1)){
        setTimeout(() => {
            $popup.addClass('show');
         }, countdown * 1000);
    }
    
    $popup.find('button.close').on("click", function(e){
        $popup.removeClass('show');
    });

    var $form = $popup.find('.subcribe-form');

    $form.on("submit", function(e){
        e.preventDefault();
        var phone_number = $form.find("#subcribe-phone-number").val();
        App.api.post(App.subcribes.urls.subcribe, {phone_number:phone_number}).then(function(rs){
            if(rs.status){
                App.popup.alert("Đăng ký theo dõi thành công!");
                $popup.removeClass('show');
            }else{
                if(rs.errors && !App.isEmpty(rs.errors)){
                    App.popup.error(Object.keys(rs.errors).map(r => rs.errors[r]).join("<br>"));
                }
                else{
                    App.popup.warning(rs.message);
                }
            }
        }).catch(function(rs){
            App.popup.error("Lỗi không xác định");
        })
    })
})
})(jQuery);