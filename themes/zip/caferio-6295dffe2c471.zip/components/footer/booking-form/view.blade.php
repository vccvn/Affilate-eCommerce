@php
    add_js_src(theme_asset('js/booking.js'));
@endphp

                        <div class="col-lg-{{$data->col_lg(4)}} col-sm-{{$data->col_sm(6)}} sm-padding">
                            <div class="footer-widget booking-form">
                                <h3>{{$data->title}} <span></span></h3>
                                <form action="{{route('client.bookings.ajax-submit')}}" method="post" id="ajax_booking_form" class="form-horizontal ajax_booking_form">
                                    @csrf
                                    <div class="booking-form-group">
                                        <div class="form-padding" style="grid-column-end: span 2;">
                                            <input type="text" id="b_name" name="name" class="form-control b_name" placeholder="Họ tên" required>
                                        </div>
                                        <div class="form-padding">
                                            <input type="tel" id="b_phone" name="phone_number" class="form-control b_phone" placeholder="Số điện thoại" required>
                                        </div>
                                        <div class="form-padding">
                                            <input type="email" id="b_email" name="email" class="form-control b_email" placeholder="Email" required>
                                        </div>
                                        <div class="form-padding">
                                            <select class="form-select b_person" id="b_person" name="quantity">
                                              <option selected value="0">Số người ăn</option>
                                              @if ($data->max_person)
                                                  @for ($i = 1; $i <= $data->max_person; $i++)
                                                      <option value="{{$i}}">{{$i}} người</option>
                                                  @endfor
                                              @endif
                                            </select>
                                        </div>
                                        <div class="form-padding">
                                            <input class="form-control b_date" type="datetime-local" id="b_date" name="booking_time">
                                        </div>
                                        <div class="form-padding">
                                            <textarea id="b_message" name="message" cols="30" rows="5" class="form-control message b_message" placeholder="Ghi chú" required></textarea>
                                        </div>
                                    </div>
                                    <button id="b_submit" class="book-btn" type="submit">Đặt bàn</button>
                                    <div id="b-form-messages" class="alert b-form-messages" role="alert"></div>
                                </form>
                            </div>
                        </div>