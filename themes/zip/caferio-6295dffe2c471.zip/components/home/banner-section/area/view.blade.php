


        <section class="banner-section padding">
            <div class="bg-shape grey"></div>
             <div class="container">
                 <div class="row banner-wrapper">
                    <div class="col-md-6 wow fadeInUp" data-wow-delay="200ms">
                        <div class="banner-item">
                             <img src="{{$data->main_banner_image}}" alt="banner">
                             <div class="banner-content">
                                 <h3>{!! $data->main_banner_sub_title !!}</h3>
                                 <h2>{!! nl2br($data->main_banner_title) !!}</h2>
                                 <p>{{$data->main_banner_description}}</p>
                                 <a href="{{$data->main_banner_url}}" class="default-btn">{{$data->main_banner_btn_text('Đặt hàng')}}</a>
                             </div>
                         </div>

                    </div>
                     <div class="col-md-6">
                        <div class="row">
                            {!! $children !!}
                        </div>
                     </div>
                 </div>
             </div>
         </section><!--/.banner-section-->
 