


        <section class="delivery-section padding {{$data->bg_color == 'grey' ? 'bg-grey': ''}} " @if ($data->bg_color == 'custom' && $data->bg_custom_color) style="background-color: {{$data->bg_custom_color}};" @endif>
            @if (in_array($data->shape_type, ['white', 'grey']))
                
            <div class="bg-shape {{$data->shape_type}}"></div>
            
            @endif
             <div class="container">
                 <div class="row align-items-center">
                     <div class="col-md-6 wow fadeInLeft" data-wow-delay="200ms">
                         <div class="delivery-info">
                            <h2>{!! nl2br($data->title) !!}</h2>
                            <p>{!!nl2br($data->description)!!}</p>
                             <div class="order-content">
                                <a href="{{$data->url}}" class="default-btn">{{$data->btn_text('Đặt hàng')}} <span></span></a>
                                <h3><span>Gọi ngay</span><a href="tel:{{$tel = $data->phone_number($siteinfo->phone_number)}}">{{$tel}}</a></h3>
                             </div>
                         </div>
                     </div>
                     <div class="col-md-6">
                        <div class="delivery-boy-wrap">
                            <img class="delivery" src="{{$data->image(theme_asset('img/cloud.png'))}}" alt="img">
                             <div class="delivery-boy"></div>
                        </div>
                     </div>
                 </div>
             </div>
         </section><!--/.delivery-section-->
