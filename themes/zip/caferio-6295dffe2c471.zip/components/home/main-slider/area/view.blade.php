
        <div id="main-slider" class="main-slider">
            {!! $children !!}
        </div><!-- slider-section -->
