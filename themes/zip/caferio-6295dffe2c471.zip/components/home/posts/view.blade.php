@php
    $args = [
        '@limit' => $data->post_number?$data->post_number:4,
        '@sort' => $data->sorttype?$data->sorttype:1,
        '@withTags' =>  true,
        '@withCategory' =>  true,
        '@withAuthor' => true,
        '@withCountPublishComments' => 'comment_count'
    ];
    $link = null;
    $title = null;
    if($data->dynamic_id && $dynamic = $helper->getDynamic(['id' => $data->dynamic_id])){
        $args['dynamic_id'] = $data->dynamic_id;
        $title = $dynamic->name;
        $link = $dynamic->getViewUrl();
    }
    if($data->category_id && $category = $helper->getPostCategory(['id' => $data->category_id])){
        $args['@category'] = $data->category_id;
        if($category->hasChild() && $data->group_by_category) $args['@groupBy'] = ['posts.category_id'];
        if(!$title) $title = $category->name;
        $link = $category->getViewUrl();
    }elseif($data->group_by_category) $args['@groupBy'] = ['posts.category_id'];
    $args['@withCategory'] = true;
    if($data->title) $title = $data->title;
    if($data->link) $link = $data->link;
@endphp

@if (count($posts = $helper->getPosts($args)))

    <section class="blog-section padding {{$data->bg_color == 'grey' ? 'bg-grey': ''}} " @if ($data->bg_color == 'custom' && $data->bg_custom_color) style="background-color: {{$data->bg_custom_color}};" @endif>
        @if (in_array($data->shape_type, ['white', 'grey']))
            
        <div class="bg-shape {{$data->shape_type}}"></div>
        
        @endif
        <div class="container">
            <div class="section-heading mb-30 text-center wow fadeInUp" data-wow-delay="200ms">
                <h4>{{ $data->sub_title }}</h4>
                <h2>{!! nl2br($title) !!}</h2>
                <p>{{$data->description}}</p>
            </div>
            <div class="row blog-posts">
                @foreach ($posts as $post)

                <div class="col-lg-3 col-md-6 sm-padding wow fadeInUp" data-wow-delay="200ms">
                    <div class="post-card">
                        <div class="post-thumb">
                            <a href="{{$u = $post->getViewUrl()}}">
                                <img src="{{$post->getThumbnail()}}" alt="{{$post->title}}">
                            </a>
                            @if ($post->category)
                                
                            <div class="category"><a href="{{$post->category->getViewUrl()}}">{{$post->category->name}}</a></div>
                            @endif
                        </div>
                        <div class="post-content">
                            {{-- <ul class="post-meta">
                                <li><i class="far fa-calendar-alt"></i><a href="{{$u}}#date">{{$post->dateFormat('d/m/Y')}}</a></li>
                                <li><i class="far fa-user"></i><a href="{{$u}}#uthor">{{$post->author?$post->author->name:''}}</a></li>
                            </ul> --}}
                            <h4><a href="{{$u}}">{{$post->sub('title', 80)}}</a></h4>
                            <p>{{$post->getShortDesc(100)}}</p>
                            <a href="{{$u}}" class="read-more">Xem thêm <i class="las la-long-arrow-alt-right"></i></a>
                        </div>
                    </div>
                </div>
            @endforeach
            </div>
        </div>
    </section><!-- /.blog-section -->

 @endif