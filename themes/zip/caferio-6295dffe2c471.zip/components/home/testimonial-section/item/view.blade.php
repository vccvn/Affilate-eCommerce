

<div class="swiper-slide">
    <div class="testimonial-item">
        <div class="testi-thumb">
            <img src="{{$data->avatar}}" alt="{{$data->name}}">
            <div class="author">
                <h3>{{$data->name}}</h3>
                <h4>{{$data->job}}</h4>
            </div>
        </div>
        <p> "{{$data->comment}}"</p>
        <ul class="ratting">

            
        @for ($i = 0; $i < $data->rating; $i++)
        <li><i class="las la-star"></i></li>
        @endfor
        </ul>
    </div>
</div>