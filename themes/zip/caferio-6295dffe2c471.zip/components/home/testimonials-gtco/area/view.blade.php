@php
    add_css_link('https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.carousel.min.css');
    add_js_src('https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/owl.carousel.min.js');
    add_js_src(theme_asset('js/testimonials.js'));
    
    $selector = "#caferio-component-$component->id";
    if($data->text_color){
        $html->addCss($selector, [
            'color' => $data->text_color
        ]);
    }
    if($data->h_color){
        $html->addCss("$selector h4, $selector h3, $selector h2", [
            'color' => $data->text_color
        ]);
    }    
    if($data->sub_color){
        $html->addCss("$selector h4", [
            'color' => $data->sub_color
        ]);
    }
    if($data->title_color){
        $html->addCss("$selector h2", [
            'color' => $data->title_color
        ]);
    }
    
    if($data->p_color){
        $html->addCss("$selector p", [
            'color' => $data->p_color
        ]);
    }
    
    if($data->link_color){
        $html->addCss("$selector a", [
            'color' => $data->link_color
        ]);
    }
    
    if($data->link_hover_color){
        $html->addCss("$selector a:hover", [
            'color' => $data->link_hover_color
        ]);
    }
    if($data->card_title_color){
        $html->addCss("$selector .card-body h5", [
            'color' => $data->card_title_color
        ]);
    }

    if($data->card_title_span_color){
        $html->addCss("$selector .card-body h5 span", [
            'color' => $data->card_title_span_color
        ]);
    }
    
    if($data->card_text_color){
        $html->addCss("$selector .gtco-testimonials .cart-body p", [
            'color' => $data->card_text_color
        ]);
    }
    
    
    
    if($data->bg_type == 'image' && $data->bg_image){
        $html->addCss("$selector, $selector.bg-grey", [
            'background' => "url('$data->bg_image') no-repeat center center",
            'background-size' => 'cover'
        ]);
    }
    if($data->bg_type == 'custom' && $data->bg_color){
        $html->addCss("$selector, $selector.bg-grey", [
            'background-color' => $data->bg_color
        ]);
    }

@endphp
        
        <section class="testimonial-section {{$data->bg_type == 'grey' ? 'bg-grey': ''}} padding" @if ($data->bg_type == 'custom' && $data->bg_custom_color) style="background-color: {{$data->bg_custom_color}};" @endif id="caferio-component-{{$component->id}}">
            @if (in_array($data->shape_type, ['white', 'grey']))
                
            <div class="bg-shape {{$data->shape_type}}"></div>
            
            @endif
            <div class="container">
                <div class="section-heading mb-30 text-center wow fadeInUp" data-wow-delay="200ms">
                    <h4>{{$data->sub_title('Testimonials')}}</h4>
                    <h2>{!! nl2br($data->title) !!}</h2>
                    <p>{!! nl2br($data->description) !!}</p>
                </div>

                <div class="gtco-testimonials {{$data->is_image_slides?'image-slides':''}}" data-timeout="{{$data->timeout(5)}}">
                    <div class="gtco-slides">
                        <div class="owl-carousel owl-carousel1 owl-theme">
                            
                            @if ($data->list_type == 'data')
                                @if ($data->item_number > 0 && count($reviews = $helper->getProductReviews(['@sort' => $data->sort_type, '@limit' => $data->item_number])))
                                    @foreach ($reviews as $review)

                                        <div>
                                            <div class="card text-center">
                                                <img class="card-img-top" src="{{$review->getFeatureImage()}}" alt="{{$review->review_name}}">
                                                <div class="card-body">
                                                    <h5>{{$review->review_name}} <br />
                                                    <span> Khách hàng </span>
                                                    </h5>
                                                    <p class="card-text">“ {{$review->comment}} ” </p>
                                                    <ul class="ratting">
                                                        @for ($i = 0; $i < $review->rating; $i++)
                                                            <li><i class="las la-star"></i></li>
                                                        @endfor
                                                    </ul>
                                                </div>
                                            </div>
                                        </div>

                                    @endforeach
                                @endif
                            @else
                                @php
                                    if($children){
                                        $children->share(['is_image_slides' => $data->is_image_slides]);
                                    }
                                @endphp
                                {!! $children !!}
                            @endif
                            
                            
                        </div>
                    </div>
                </div>
                
             </div>
         </section><!--/.testimonial-section-->