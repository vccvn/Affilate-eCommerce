
<div class="call-us-popup" data-countdown="{{$data->countdown(30)}}" data-frequency="{{$data->frequency('wlways')}}">
    <div class="cookiesContent" id="cookiesPopup">
        <button class="close">✖</button>
        <img src="{{$data->icon('https://cdn-icons-png.flaticon.com/512/1047/1047711.png')}}" alt="cookies-img" />
        <p>{{$data->description}}</p>
        <a class="accept" href="tel:{{$data->hotline('0945786960')}}">{{$data->button_text('Gọi ngay')}}</a>
    </div>
</div>
