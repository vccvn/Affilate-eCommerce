<?php
    add_js_src(theme_asset('plugins/subscribes/script.js'));
?>
<link rel="stylesheet" href="{{theme_asset('plugins/subscribes/style.css')}}">

<div class="subscribe-popup" data-countdown="{{$data->countdown(30)}}" data-frequency="{{$data->frequency('wlways')}}">
    <div class="subscribeContent" id="subscribePopup">
        <button class="close">✖</button>
        <div class="content-wrapper">
            <h3>Nhận ưu đãi</h3>
            <form action="{{route('client.subcribe')}}" class="subcribe-form ">
                <label for="subcribe-phone-number">
                    Đăng ký để nhận thông tin khuyến mãi
                </label>
                <div class="inp-group">
                    <input type="text" name="phone_number" placeholder="Nhập số điện thoại" id="subcribe-phone-number">
                    <button type="submit">Đăng ký</button>
                </div>
            </form>
        </div>
    </div>
</div>
