@php
    if(isset($children) && $children){
        $children->share(['show_info' => $data->show_info, 'thumbnail_size' => $data->thumbnail_size]);
    }
@endphp

<section class="food-menu {{$data->bg_color == 'grey' ? 'bg-grey': ''}} padding" @if ($data->bg_color == 'custom' && $data->bg_custom_color) style="background-color: {{$data->bg_custom_color}};" @endif>
    @if (in_array($data->shape_type, ['white', 'grey']))
        
    <div class="bg-shape {{$data->shape_type}}"></div>
    
    @endif
    <div class="container">
        @if ($data->sub_title || $data->title || $data->description)
            
        <div class="section-heading mb-30 text-center wow fadeInUp" data-wow-delay="200ms">
            @if ($data->sub_title)
            <h4>{{ $data->sub_title }}</h4>
            @endif
            @if ($data->title)
            <h3>{!! nl2br($data->title) !!}</h3>
            @endif
            
            <p>{!!  nl2br($data->description) !!}</p>
        </div>
        
        @endif
        <div class="row">
            {!! $children !!}
        </div>
                
                
    </div>
</section><!--/.food-menu-->

