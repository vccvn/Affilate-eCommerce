@php
    $name = '';
    $price = 0;
    $oldPrice = 0;
    $thumbnail = '';
    $url = '';
    $hasPromo = false;
    $category_name = '';
    $downPercent = 0;

    $reviews = null;

    $product_id = $data->product_id;
    $style = isset($style) ? $style : 'grid';
    $params = ['id' => $data->product_id];
    $hasProduct = false;
    $hasOption = false;
    if($style == 'slides'){
        $params = array_merge($params, [
            '@with' => ['promoAvailable'],
            '@withReviews' => true,
            '@withCategory' => true
        ]);
    }

    $allowOrder = false;
    if($data->product_id && $product = $helper->getProduct($params)){
        $name = $product->name;
        $price = $product->getFinalPrice();
        $thumbnail = $product->getThumbnail();
        $url = $product->getViewUrl();
        $hasPromo = $product->hasPromo();
        $downPercent = $product->getDownPercent();
        $category_name = $product->category->name;
        $reviews = $product->getReviewData();
        $oldPrice = $product->priceFormat('list');
        $allowOrder = $ecommerce->allow_place_order && $product->price_status > 0 && $product->status > 0;
        $hasOption = $product->hasOption();
        $hasProduct = true;
        $url = $product->getViewUrl();
        
    }else{
        $allowOrder = $data->allow_order;
    }
    $name = $data->name($name);
    $price = $data->price($price);
    $hasPromo = $data->has_promo($hasPromo);
    $oldPrice = $data->old_price($oldPrice);
    $down_percent = $data->down_percent($downPercent);
    $thumbnail = $data->thumbnail($thumbnail);
    $category_name = $data->category_name($category_name);
    $url = $data->url($url);

    if($data->price_format == 'k'){
        $price = number_format($price/1000, 0, ',', '.') . 'k';
    }else{
        $price = $helper->getCurrencyFormat($price);
    }


    $show_info == isset($show_info) && $show_info ? true : false;


@endphp

<div class="col-xl-{{$data->col_xl(3)}} col-lg-{{$data->col_lg(4)}} col-sm-{{$data->col_sm(6)}} padding-15">
    <div class="swiper-slide">
        <div class="product-item {{$thumbnail_size}}">
            @if ($hasPromo && $downPercent)

            <div class="sale">-{{$downPercent}}%</div>

            @endif
            <div class="product-thumb">
                @if (!$url)
                <a class="img-popup" data-gall="gallery01"  href="{{$thumbnail}}"><img src="{{$thumbnail}}" alt="{{$name}}"></a>
                @else
                <a href="{{$url}}"><img src="{{$thumbnail}}" alt="{{$name}}"></a>
                @endif
                    
                
                @if (isset($show_info) && $show_info)
                    
                <div><a href="{{$url}}" class="order-btn {{(!$hasOption && $hasProduct && $allowOrder)? parse_classname('add-to-cart'):'product-quick-view '.parse_classname('product-quick-view') }}" data-product-id="{{$product->id}}" data-redirect="checkout">{{(!$hasOption && $hasProduct && $allowOrder)?'Đặt hàng':'Chi tiết'}}</a></div>
                
                @endif
            </div>
            @if (isset($show_info) && $show_info)
                
                <div class="food-info">
                    <ul class="ratting">
                        @if ($category_name)
                        <li>{{$category_name}}</li>
                        @endif

                        @if ($reviews&&$reviews->total)
                        @php
                        $rateAvgInt = $reviews->rating_int;

                        $rateAvgFlloat = $reviews->rating_avg;

                        // Danh gia trung binh

                        @endphp
                        {{-- lặp qua từ 0 den so sao --}}
                        @for ($i = 0; $i < $rateAvgInt; $i++) <li><i class="las la-star"></i></li>

                            @endfor
                            {{-- nếu rate_avg > rate_int thì cộng thêm nữa sao --}}
                            @if ($rateAvgFlloat > $rateAvgInt)
                            <li><i class="las la-star-o"></i></li>
                            @endif
                            @endif
                    </ul>
                    <h3><a href="{{$url}}">{{$name}}</a></h3>
                    <div class="price">
                        <h4>
                            Giá: <span>{{$price}}</span>
                            @if ($hasPromo)

                            <span class="reguler">{{$oldPrice}}</span>
                            @endif
                        </h4>
                    </div>
                </div>
            @endif
        </div>
    </div>
</div>
