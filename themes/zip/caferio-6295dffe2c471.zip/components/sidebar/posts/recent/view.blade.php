@php
    $args = [
        '@limit' => $data->post_number?$data->post_number:20,
        '@sort' => $data->sorttype?$data->sorttype:1
    ];
    $title = null;
    if($data->dynamic_id && $dynamic = $helper->getDynamic(['id' => $data->dynamic_id])){
        $args['dynamic_id'] = $data->dynamic_id;
        $title = $dynamic->name;
    }
    if($data->category_id && $category = $helper->getPostCategory(['id' => $data->category_id])){
        $args['@category'] = $data->category_id;
        if(!$title) $title = $category->name;
    }
    
    if($data->content_type && $data->content_type != 'all'){
        $args['content_type'] = $data->content_type;
    }
    if($data->title) $title = $data->title;
    
@endphp


<div class="blog-sidebar-section -trending-post">
    <div class="center-line-title">
        <h5></h5>
    </div>


</div>


<div class="sidebar-widget">
    <div class="widget-tittle">
        <h2>{{$title?$title:'Mới nhất'}}</h2>
        <span></span>
    </div>
    <ul class="recent-post">
        @if (count($posts = $helper->getPosts($args)))
            @foreach ($posts as $post)
                <li>
                    <div class="thumb">
                        <img src="{{$post->getImage('90x90')}}" alt="{{$post->title}}">
                    </div>
                    <div class="recent-post-meta">
                        <h3><a href="{{$u = $post->getViewUrl()}}">{{$post->title}}</a></h3>
                        <a href="{{$u}}#date" class="date"><i class="far fa-calendar-alt"></i>{{$post->dateFormat('d/m/Y')}}</a>
                    </div>
                </li>
                
            @endforeach
        @endif
    </ul>
</div><!--/.recent-posts -->
