
                        <div class="sidebar-widget">
                            <div class="widget-tittle">
                                <h2>{{$data->title}}</h2>
                                <span></span>
                            </div>
                            {!!
                                $helper->getCustomMenu(['id' => $data->menu_id], 1, [
                                    'class' => 'social-widget'
                                ])
                            !!}
                        </div>