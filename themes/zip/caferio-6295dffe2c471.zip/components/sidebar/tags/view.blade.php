@if (count($tags = $helper->getTags(['@sort'=> $data->sorttype, '@limit' => $data->tag_number])))


    

<div class="sidebar-widget">
    <div class="widget-tittle">
        <h2>{{$data->title('Thẻ bải viết')}}</h2>
        <span></span>
    </div>
    <ul class="tags">
        @foreach ($tags as $tag)
        <li>
            <a href="{{route('client.posts.tag', ['tag' => $tag->slug])}}">{{$tag->name}}</a>
        </li>
        @endforeach
    </ul>
</div><!--/.tags -->
@endif