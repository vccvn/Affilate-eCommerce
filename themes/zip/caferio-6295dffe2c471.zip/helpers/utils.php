<?php

if (!function_exists('get_caferio_post_settings')) {
    /**
     * lấy thiết lập cho post
     */
    function get_caferio_post_settings($id = null, $category_id = 0)
    {
        static $settings = [];
        if (array_key_exists($id, $settings) && array_key_exists($category_id, $settings[$id])) return $settings[$id][$category_id];
        if ($html = get_web_data('__html__')) {
            if ($post_settings = $html->post_settings) {
                if ($components = $post_settings->components->getComponents()) {
                    foreach ($components as $comp) {
                        if ($comp->data->dynamic_id == $id) {
                            if (!array_key_exists($id, $settings)) $settings[$id] = [];
                            if (!$category_id) {
                                $settings[$id][0] = $comp->data;
                                return $comp->data;
                            } elseif ($category_id == $comp->data->category_id) {
                                $settings[$id][$comp->data->category_id] = $comp->data;
                                return $comp->data;
                            }
                        }
                    }
                    if (array_key_exists($id, $settings) && array_key_exists(0, $settings[$id])) {
                        $settings[$id][$category_id] = $settings[$id][0];
                        return $settings[$id][0];
                    }
                }
            }
        }
        return [];
    }
}

if (!function_exists('get_caferio_post_setting_data')) {
    /**
     * lấy thiết lập cho post
     */
    function get_caferio_post_setting_data($dynamic, $category = null, $scope = 'list')
    {
        $postSettings = get_option()->theme->posts;
        $sub_title = $postSettings->sub_title;
        $title = $dynamic->name;
        $description = $dynamic->description;
        $header_image = '';
        $category_id = 0;
        if ($postSettings->header_use_bg_image) {

            if ($postSettings->use_dynamic_deta && $dynamic->feature_image && $dfi = $dynamic->getFeatureImage()) {
                $header_image = $dfi;
            } else {
                $header_image = $postSettings->header_bg_image;
            }
        }
        if (isset($category) && $category) {
            $category_id = $category->id;
            $title = $category->name;
            $sub_title = $dynamic->name;

            if ($postSettings->header_use_bg_image && $category->feature_image && $gfi = $category->getFeatureImage()) {
                $header_image = $gfi;
            }
        }


        if ($dynamicSettings = get_caferio_post_settings($dynamic->id, $category_id)) {
            $postSettings = $dynamicSettings;
            if ($postSettings->list_use_category_deta && !$postSettings->category_id) {
                if (isset($category) && $category && $category->description) {
                    $description = $category->description;
                }
            } else {
                if ($postSettings->sub_title) $sub_title = $postSettings->sub_title;
                if ($postSettings->title) $title = $postSettings->sub_title;
                if ($postSettings->description) $description = $postSettings->description;
                if ($postSettings->header_use_bg_image && $postSettings->header_bg_image) $header_image = $postSettings->header_bg_image;
            }
        }
        return compact('postSettings', 'sub_title', 'title', 'description', 'header_image');
    }
}


if (!function_exists('get_caferio_page_settings')) {
    /**
     * thêm dấu trang
     */
    function get_caferio_page_settings($id = null)
    {
        static $settings = [];
        if (array_key_exists($id, $settings)) return $settings[$id];
        if ($html = get_web_data('__html__')) {
            if ($post_settings = $html->page_settings) {
                if ($components = $post_settings->components->getComponents()) {
                    foreach ($components as $comp) {
                        if ($comp->data->page_id == $id) {
                            $settings[$id] = $comp->data;
                            return $comp->data;
                        }
                    }
                }
            }
        }
        return [];
    }
}
if (!function_exists('get_caferio_page_component')) {
    /**
     * thêm dấu trang
     */
    function get_caferio_page_component($id = null)
    {
        static $components = [];
        if (array_key_exists($id, $components)) return $components[$id];
        if ($html = get_web_data('__html__')) {
            if ($post_settings = $html->page_settings) {
                if ($components = $post_settings->components->getComponents()) {
                    foreach ($components as $comp) {
                        if ($comp->data->page_id == $id) {
                            $settings[$id] = $comp;
                            return $comp;
                        }
                    }
                }
            }
        }
        return null;
    }
}

if (!function_exists('get_caferio_product_setting_data')) {
    /**
     * lấy thiết lập cho post
     */
    function get_caferio_product_setting_data($category = null, $scope = 'list', $defaultTitle = 'Thực đơn')
    {
        $productSettings = get_option()->theme->products;
        $sub_title = $productSettings->sub_title;
        $title = $productSettings->title($defaultTitle);
        $description = $productSettings->description;
        $header_image = '';
        $category_id = 0;
        if ($productSettings->header_use_bg_image) {

            $header_image = $productSettings->header_bg_image;
        }
        if ($category) {
            $category_id = $category->id;
            if ($productSettings->use_category_deta) {
                $sub_title = $title;
                $title = $category->name;
                if ($category->description) {
                    $description = $category->description;
                }
            }
            if ($productSettings->header_use_bg_image && $category->feature_image && $gfi = $category->getFeatureImage()) {
                $header_image = $gfi;
            }
        }

        return compact('productSettings', 'sub_title', 'title', 'description', 'header_image');
    }
}


if (!function_exists('get_caferio_component_css')) {
    /**
     * lấy thiết lập cho post
     */
    function get_caferio_component_css($component_id, $styles = [], $selectors = null)
    {
        if(!count($styles)) return false;

        $s = $selectors ? (is_array($selectors) ? $selectors: array_filter(array_map(function ($v) {
            return trim($v);
        }, explode(',', $selectors)), function ($v) {
            return $v ? true : false;
        })): [];
        $prefix = '#caferio-component-' . $component_id . ' ';
        $str = '';

        if($s){
            foreach ($s as $n => $p) {
                $str .= ($n?', ': ''). $prefix . $p;
                    
            }    
        }
        $str .=   '{';
            foreach ($styles as $attr => $value) {
                $str .= str_slug(str_snake($attr)). ': '. $value . ';';
            }
        $str .= '}';
        
        return $str;
    }
}



if (function_exists('add_shortcode')) {
    add_shortcode('single-post-list', 'caferio_single_post_list_shortcode');
    function caferio_single_post_list_shortcode($args, $content)
    {
        $params = is_array($args) ? $args : [];

        $title = array_key_exists('title', $params) ? $params['title'] : '';
        $content = '
        <ul class="single-post-list">
            <h4>' . $title . '</h4>
            ' . implode('', array_map(function ($line) {
            return '<li><i class="fas fa-check"></i>' . $line . '</li>';
        }, nl2array(strip_tags($content)))) . '
            
        </ul>
        ';
        return $content;
    }
}
