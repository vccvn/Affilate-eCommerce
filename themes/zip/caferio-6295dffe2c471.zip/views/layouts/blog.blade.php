@extends($_layout.'master')
@section('page.header.show', $__env->yieldContent('blog.header', 1))

@section('container')
    

@php
    $layout = $__env->yieldContent('page.layout', 'sidebar');
@endphp

<section class="blog-section bg-grey padding">
    <div class="bg-shape white"></div>
    <div class="container">
        <div class="row blog-posts">
            <div class="col-lg-{{$layout == 'sidebar' ? 8 : 12}} sm-padding">
                @yield('page.content')
            </div><!--/. col-lg-{{$layout == 'sidebar' ? 8 : 12}} -->
            @if ($layout == 'sidebar')
                
            <div class="col-lg-4 sm-padding">
                <div class="sidebar-wrap">
                    {!! $html->sidebar_posts->components !!}
                </div>
            </div><!--/. col-lg-4 -->
            
            @endif
        </div>
    </div>
</section><!--/. blog-section -->

@endsection