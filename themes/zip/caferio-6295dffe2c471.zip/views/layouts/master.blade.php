<!doctype html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7" lang=""> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8" lang=""> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9" lang=""> <![endif]-->
<!--[if gt IE 8]><!--> <html class="no-js" lang="vi"> <!--<![endif]-->

<head>
    @include($_lib.'meta')
    @include($_template.'links')
    
    {!! $html->head->embeds !!}


</head>
@php
    $__body_class__ = isset($body_class) && $body_class ? $body_class : $__env->yieldContent('body.class', 'header-1');
    $show_header = $__env->yieldContent('page.header.show');
@endphp
<body class="{{$__body_class__}}">

    {!! $html->top->embeds !!}
        
    <!--[if lt IE 8]>
        <p class="browserupgrade">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade your browser</a> to improve your experience.</p>
    <![endif]-->

    <div class="site-preloader-wrap">
        <div class="spinner"></div>
    </div><!-- /.site-preloader-wrap -->

    @include($_template.'header')

    @if(in_array($show_header, ["breadcrumb", "breadcrumbs"]))
        @include($_template.'breadcrumbs')
    @elseif(in_array($show_header, ['show', 1, true, "true", "on"]))
        @include($_template.'page-header')
    @endif

    @yield('container')

    @include($_template.'footer')
    
    <div id="scrollup">
        <button id="scroll-top" class="scroll-to-top"><i class="las la-arrow-up"></i></button>
    </div>

    {!! $html->plugins->components !!}

    @include($_template.'js')

    {!! $html->bottom->embeds !!}

</body>


</html>