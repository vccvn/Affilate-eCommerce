@extends($_layout.'master')

@section('container')
    

@php
    $layout = $__env->yieldContent('page.layout', 'sidebar');
@endphp
<section class="page-header">
    <div class="bg-shape grey"></div>
    <div class="container">
        <div class="page-header-content">
            @if ($sub_title = $__env->yieldContent('page.sub_title'))
            <h4>{!! $sub_title !!}</h4>
            @endif
            @if ($_title = $__env->yieldContent('page.title'))
            <h2>{!! $_title !!}</h2>
            @endif
            
            @if ($_description = $__env->yieldContent('page.description'))
            <p>{!! $_description !!}</p>
            @endif
            
        </div>
    </div>
</section><!--/.page-header-->
@if ($layout == 'page')
    @yield('page.content')
@else


    <section class="blog-section bg-grey padding">
        <div class="bg-shape white"></div>
        <div class="container">
            <div class="row blog-posts">
                <div class="col-lg-{{$layout == 'sidebar' ? 8 : 12}} sm-padding">
                    @yield('page.content')
                </div><!--/. col-lg-{{$layout == 'sidebar' ? 8 : 12}} -->
                @if ($layout == 'sidebar')
                    
                <div class="col-lg-4 sm-padding">
                    <div class="sidebar-wrap">
                        {!! $html->sidebar_posts->components !!}



                    </div>
                </div><!--/. col-lg-4 -->
                
                @endif

            </div>
        </div>
    </section><!--/. blog-section -->

            
@endif

@endsection