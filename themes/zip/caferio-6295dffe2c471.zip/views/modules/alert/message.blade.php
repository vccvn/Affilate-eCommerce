<?php
$type = isset($type) && $type ? $type : (session('type') ? session('type') : 'success');
$message = isset($message) && $message ? $message : (session('message') ? session('message') : 'Hello World');
$link = isset($link) ? $link : (session('link') ? session('link') : route('home'));
$text = isset($text) ? $text : (session('text') ? session('text') : '<i class="fa fa-home"></i> Về trang chủ');
$title = isset($title) && $title ? $title : (session('title') ? session('title') : 'Thông báo');
$t = in_array($type, ['success', 'error']) ? $type : 'general';
$page_tirle = $title;
?>




@extends($_layout.'blog')
@section('page.layout', 'fullwidth')
@section('title', "Thông báo")
@include($_lib.'register-meta')
@section('header.style', 1)

@section('page.title', $title)
{{-- @section('page.description', $settingData['description']) --}}


@section('page.content')


    <div class="alert alert-{{$t}} text-center">{!! $message !!}</div>
    <div class="text-center mt-20">
        <a href="{{$link}}" class="default-btn">{{$text}}</a>
    </div>
    

@endsection