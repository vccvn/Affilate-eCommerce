@php
    $home = $options->theme->home;
@endphp
@if ($home->title)
    @section('title', $home->title)
@endif
@if ($home->description)
    @section('description', $home->description)
@endif
@if ($home->thumbnail)
    @section('image', $home->thumbnail)
@endif

@extends($_layout.'master')

@section('container')
    
    {!! $html->home_area->components !!}

@endsection
