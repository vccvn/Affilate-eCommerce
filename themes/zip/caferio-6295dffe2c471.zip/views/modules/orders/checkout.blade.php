@extends($_layout.'master')

@section('container')
@include($_template.'breadcrumbs', [
    'sub_title' => 'Checkout',
    'title' => "Đặt hàng"
])

        
    <section class="checkout-section bg-grey padding">
        <div class="container">
            @if ($cart && $cart->details && count($cart->details))
                @php
                    $form = $cart->getForm([
                        'className' => 'form-control',
                    ]);
                    
                    $info = $form->get('billing_name', 'billing_email', 'billing_phone_number', 'billing_region_id', 'billing_district_id', 'billing_ward_id', 'billing_address');
                    $shipping = $form->get('shipping_name', 'shipping_email', 'shipping_phone_number', 'shipping_region_id', 'shipping_district_id', 'shipping_ward_id', 'shipping_address');
                @endphp
                <form action="{{route('client.orders.place-order')}}" class="{{parse_classname('checkout-form', 'place-order-form')}}" method="POST">
                    @csrf
                    <div class="row">
                        <div class="col-lg-8 sm-padding">
                                <h3>Thông tin khách hàng</h3>
                                <div class="checkout-form mb-30">
                                    @foreach ($info as $input)
                                        <div class="inp-group {{$loop->index == 0 ? 'grid-column-2' : ''}} grid-column-sm-2">
                                            <label for="{{ $input->id }}">
                                                {{ $input->label }}
                                                @if ($input->required)
                                                    <sup>*</sup>
                                                @endif
                                            </label>
                                            <div class="form-field">
                                                {!! $input !!}
                                            </div>
                                            @if ($input->error)
                                                <div class="error has-error">{{ $input->error }}</div>
                                            @endif
                                        </div>
                                    @endforeach
                                </div>

                                @if (!$helper->isLogin())
                                <div class="account-group {{parse_classname('account-group')}}">
                                    <div class="form-group">
                                        <div class="checkbox-group">
                                            {{-- <label> --}}
                                                {!! $create = $form->get('create_account')->addClass(parse_classname('create-account-checkbox'))->removeClass('form-control') !!}
                                                {{-- <i class="circle uncheck"></i> <i class="circle uncheck fas fa-check"></i> 
                                                <span>Tạo tài khoản</span> --}}
                                            {{-- </label> --}}
                                        </div>
                                    </div>

                                    <div class="create-account-group  {{parse_classname('create-account-group')}} {{$create->value?'show':''}}">
                                        <p>Tạo một tài khoản từ thông tin đơn hàng. Lần tới mua hàng bạn có thể dùng tài khoản này để đặt hàng dễ dàng hơn và tiện quản lý</p>
                                        <div class="checkout-form">
                                            <div class="form-group">
                                                <label for="{{($input = $form->password)->id}}">
                                                    {{$input->label}}
                                                </label>
                                                <div class="form-field">
                                                {!! $input !!}
                                                </div>
                                                @if ($input->error)
                                                    <div class="error has-error">{{$input->error}}</div>
                                                @endif
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                @endif

                                                                
                                <div class="shipping-group {{parse_classname('shipping-group')}}">
                                    <div class="form-group">
                                        <div class="ps-checkbox">
                                            {!! $checkbox = $form->get('ship_to_different_address')->addClass(parse_classname('ship-to-different-address'))->removeClass('form-control') !!}
                                        </div>
                                    </div>
                                    <div class="shipping-address-group {{parse_classname('shipping-address-group')}} {{$checkbox->value?'show':''}}">
                                        <div class="checkout-form mt-30">
                                            @foreach ($shipping as $input)
                                                <div class="inp-group {{$loop->index == 0 ? 'grid-column-2' : ''}} grid-column-sm-2">
                                                    <label for="{{$input->id}}">
                                                        {{$input->label}}
                                                        @if ($input->required)
                                                        <sup>*</sup>
                                                        @endif
                                                    </label>
                                                    <div class="form-field">
                                                    {!! $input !!}
                                                    </div>
                                                    @if ($input->error)
                                                        <div class="error has-error">{{$input->error}}</div>
                                                    @endif
                                                </div>
                                            @endforeach
                                        </div>
                                    </div>
                                </div>
                                
                                <div class="additional-info mb-30">
                                    <div class="form-field">
                                        <label for="{{($input = $form->note)->id}}">
                                            {{$input->label}}
                                        </label>
                                        <div class="form-group__content">
                                        {!! $input !!}
                                        </div>
                                        
                                    </div>
                                    
                                </div>
                                <div class="payment-method">
                                    <h3>Thanh toán</h3>
                                                
                                    <div class="panel-default">
                                        @include($_lib.'payments.methods')
                                    </div>
                                    <div class="order_button">
                                
                                        <button type="submit" class="default-btn">Đặt hàng <span></span></button>
                                    </div>

                                    {{-- <ul class="mb-20">
                                        <li>
                                            <input type="radio" id="option-1" name="selector" checked="">
                                            <label for="option-1">Direct Bank Transfer</label>
                                        </li>
                                        <li>
                                            <input type="radio" id="option-2" name="selector">
                                            <label for="option-2">Check Payments</label>
                                        </li>
                                        <li>
                                            <input type="radio" id="option-3" name="selector">
                                            <label for="option-3">Cash On Delivery</label>
                                        </li>
                                    </ul>
                                    <a href="#" class="">Place Order</a>
                                    --}}
                                </div>
                        </div>
                        <div class="col-lg-4 sm-padding">
                            <ul class="cart-total">
                                <li><span>Tạm tính:</span> <i class="{{parse_classname('cart-sub-total-amount')}}">{{$helper->getCurrencyFormat($cart->sub_total)}}</i></li>
                                <li><span>Phí giao hàng:</span> <i>Miễn phí 150KM</i></li>
                                <li><span>Khuyến mải:</span> <strong class="{{parse_classname('cart-promo-amount')}}">{{$helper->getCurrencyFormat($cart->promo_total)}} </strong></li>
                                <li><span>Tổng tiền:</span> <strong class="{{parse_classname('cart-total-amount')}}">{{$helper->getCurrencyFormat($cart->total_money)}} </strong></li>
                                <li>
                                    <a href="{{route('client.orders.cart')}}">Giỏ hàng</a>
                                    {{-- <a href="#" class="default-btn">Checkout <span></span></a> --}}
                                </li>
                            </ul>
                        </div>
                    </div>
                </form>
            @endif
        </div>
    </section><!--/.checkout-section-->

@endsection
