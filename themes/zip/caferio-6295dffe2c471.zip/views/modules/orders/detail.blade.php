
@extends($_layout.'master')

@section('container')
@include($_template.'breadcrumbs', [
    'sub_title' => 'Quản lý đơn hàng',
    'title' => "Chi tiết đơn hàng"
])

        
    <section class="cart-section bg-grey padding">
        <div class="container">
            @if ($order && $order->details && count($order->details))
            <div class="row">
                
                <div class="col-lg-4 sm-padding">

                    <ul class="cart-total">
                        <li><h3>Hóa đơn</h3></li>
                        <li><span>Mã đơn hàng</span>{{ $order->id }}</li>
                        <li><span>Trạng thái</span>{{ $order->getStatusLabel() }}</li>
                        <li><span>Thanh toán</span>{{ $order->getPaymentMethodText() }}</li>
                        <li><span>Tạm tính</span>{{ get_currency_format($order->sub_total) }}</li>
                        <li><span>Phí giao hàng</span>{{ get_currency_format($order->shipping_fee) }}</li>
                        <li><span>Khuyến mãi</span>{{ get_currency_format($order->promo_total) }}</li>
                        <li><span>Tổng tiền</span>{{ get_currency_format($order->total_money) }}</li>
                    </ul>
                    <div class="form-group">
                        @if (!$order->isPaymentMethod('cod') && $order->isStatus('pending-payment'))
                            <a href="{{ route('client.payments.check-order', ['order_id' => $order->id, 'contact' => $order->billing->email]) }}"
                                class=" food-btn w-100p btn btn-outline-danger"><button class="button">Thanh toán</button></a>
                        @endif
                        @if ($order->canCancel())
                            <a href="#"
                                class="{{ parse_classname('btn-cancel-order') }} d-block text-center btn btn-outline-danger pt-2 pb-2"
                                data-id="{{ $order->id }}"><button class="button">Hủy</button></a>
                        @endif

                    </div>
                    


                </div>
                <div class="col-lg-8 sm-padding">
                    <div class="row cart-header">
                        <div class="col-lg-5">Sản phẩm</div>
                        <div class="col-lg-1">Số lượng</div>
                        <div class="col-lg-3">Giá</div>
                        <div class="col-lg-3">Thành tiền</div>
                    </div>
                    @foreach ($order->details as $item)
                        <div class="row cart-body {{$loop->last?'':'pb-30'}} {{ parse_classname('cart-item', 'cart-item-' . $item->id) }}" id="cart-item-{{ $item->id }}">
                            <div class="col-5 col-lg-5">
                                <div class="cart-item">
                                    <a href="{{ $item->link }}"><img src="{{ $item->image }}" alt="{{$item->product_name}}"></a>
                                    <div class="cart-content">
                                        <h3><a href="{{ $item->link }}" target="_blank">{{$item->product_name}}</a></h3>
                                        @if ($item->attributes && count($item->attributes))
                                            <p>
                                                @foreach ($item->attributes as $i => $attr)
                                                <span>{{ $attr->label ?? $attr->name }}: <strong>{{ $attr->text }}</strong></span>
                                                @if (!$i)
                                                    <br />
                                                @endif
                                                @endforeach
                                            </p>
                                        @endif
                                    </div>
                                </div>
                            </div>
                            <div class="col-1 col-lg-1">
                                <div class="cart-item">
                                    {{ $item->quantity }}
                                </div>
                            </div>
                            <div class="col-3 col-lg-3">
                                <div class="cart-item">
                                    <p>{{ $item->getPriceFormat() }}</p>
                                </div>
                            </div>
                            <div class="col-3 col-lg-3">
                                <div class="cart-item">
                                    <p><span class="{{ parse_classname('item-total-price') }}">{{ $item->getTotalFormat() }}</span></p>
                                </div>
                            </div>
                        </div>
        
        
        
        
        
                    @endforeach

                </div>

            </div>
            @else
                <div class="alert alert-warning text-center">
                    Không có đơn hàng nào!
                </div>
            @endif
        </div>
    </section><!--/.checkout-section-->

@endsection
