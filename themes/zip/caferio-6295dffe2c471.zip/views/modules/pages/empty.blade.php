@php
$postSettings = $options->theme->pages;
if (isset($parent)) {
    if ($dynamicSettings = get_caferio_page_settings($parent->id)) {
        $postSettings = $dynamicSettings;
        $postSettings->merge($dynamicSettings->all());
    }
    if ($parent != $article && ($pageSettings = get_caferio_page_settings($article->id))) {
        $postSettings->merge($pageSettings->all());
    }
} elseif ($pageSettings = get_caferio_page_settings($article->id)) {
    $postSettings->merge($pageSettings->all());
}

$postOptions = $postSettings->makeByPrefix('list_');
$header_image = $postSettings->header_use_bg_image?(
    $article->id == $postSettings->page_id && $postSettings->detail_use_feature_image && $article->feature_image ? $article->getFeatureImage() : (
        $postSettings->header_bg_image($article->feature_image?$article->getFeatureImage():"")
    )
    
):"";
$sub_title = isset($parent) && $parent != $article?$parent->title:'';
$_title = $article->title;
$description = $article->description;
$layout = $postOptions->layout('sidebar');

@endphp

@extends($_layout.'page')
@section('page.layout', $layout)
@section('title', $page_title)
@include($_lib.'register-meta')
@section('header.style', $postSettings->header_style)
@if ($header_image)
    @section('header.background', $header_image)
@endif

@section('page.sub_title', $sub_title)
@section('page.title', $_title)
@section('page.description', $description)



@section('page.content')



    <div class="alert">
        Danh sách trống
    </div>

@endsection