@extends($_layout.'master')
@include($_lib.'register-meta')



<?php
$hasOption = $product->hasOption();
$hasPromo = $product->hasPromo();
$reviews = $product->getReviewData();
$votes = $product->getReviewPoints();
$intVote = (int) $votes;
$creditPageByPhone = null;
// if($productOption = $options->theme->products){
//     if($productOption->detail_layout && in_array($productOption->detail_layout, ['default', 'smart'])) $layout = $productOption->detail_layout;
//     if($productOption->phone_credit_page_id && $cpbp = $helper->getPage(['id' => $productOption->phone_credit_page_id])) $creditPageByPhone = $cpbp;
// }
?>


@section('container')
@include($_template.'breadcrumbs', [
    'sub_title' => $product->category->name,
    'title' => $product->name
])
<section class="food-details bg-grey pt-80  {{parse_classname('product-detail')}}">
    <div class="container">
        <div class="row">
            <div class="col-md-6 sm-padding product-details-wrap">
                <div class="food-details-thumb">
                    <img src="{{$thumb = $product->getFeatureImage()}}" alt="{{$product->name}}">
                    <a class="img-popup" data-gall="gallery01" href="{{$thumb}}"><i class="fas fa-expand"></i></a>
                </div>
            </div>
            <div class="col-md-6 sm-padding {{parse_classname('product-detail-info', 'product-detail-info-'.$product->id)}}" id="product-detail-{{$product->id}}" data-id="{{$product->id}}">
                <div class="product-details">
                    <div class="product-info">
                        <div class="product-inner">
                            @if ($product->category)
                                <ul class="category">
                                    <li><a href="{{$product->category->getViewUrl()}}">{{$product->category->name}}</a></li>
                                </ul>
                                
                            @endif
                            @if ($reviews->total)
                                @php
                                    $rateAvgInt = $reviews->rating_int;
                                    
                                    $rateAvgFlloat = $reviews->rating_avg;
                                @endphp
                                <ul class="rating">
                                    {{-- lặp qua từ 0 den so sao --}}
                                    @for ($i = 0; $i < $rateAvgInt; $i++) 
                                    <li><i class="fa fa-star"></i></li>
                                    @endfor
                                    {{-- nếu rate_avg > rate_int thì cộng thêm nữa sao --}}
                                    @if ($rateAvgFlloat > $rateAvgInt)
                                        <li><i class="fa fa-star-o"></i></li>
                                    @endif
                                </ul>
                            @endif
                        </div>
                        <h3>{{$product->name}}</h3>
                        <h4 class="price">Giá bán:  {{ $product->priceFormat('final') }}
                            @if ($product->hasPromo())
                                <del><small>{{ $product->priceFormat('list') }}</small></del>
                            @endif
                            
                            @if ($product->status)
                            <span>(In Stock)</span>
                            @endif
                        </h4>
                        <p>{{ $product->getShortDesc(200) }}</p>
                        
                        
                        @if ($ecommerce->allow_place_order && $product->price_status > 0 && $product->status > 0)
                            <form action="{{ route('client.orders.add-to-cart') }}" method="post"
                                class="{{ $product->price_status < 0 ? '' : parse_classname('product-order-form') }}">
                                @csrf
                                <input type="hidden" name="product_id" value="{{ $product->id }}" class="{{ parse_classname('product-order-id') }}">
                                <input type="hidden" name="redirect" value="checkout">

                                {!! $product->attributesToHtml([
                                    'section_class' => '',
                                    'attribute_class' => '',
                                    'attribute_name_class' => '',
                                    'value_list_class' => '',
                                    'value_item_class' => '',
                                    'select_class' => '',
                                    'image_class' => '',
                                    'value_text_class' => '',
                                    'radio_class' => '',
                                    'value_label_class' => '',
                                ]) !!}

                                <div class="product-btn">
                                    <input type="number" class="qty {{ $product->price_status < 0 ? '' : parse_classname('product-order-quantity', 'quantity') }} inp-quantity" title="Số lượng" value="1" maxlength="12" min="1" step="1" id="qty" name="qty" {!! $product->price_status < 0 ? 'disabled': '' !!}>
                                    <div>
                                        <button class="purchase-btn"
                                            title="Add to Cart" type="submit">
                                            <span><i class="fa fa-shopping-basket"></i> Đặt hàng<span>
                                        </button>
                                    </div>
                                </div>

                            </form>
                        @endif
                        <ul class="product-meta">
                            @if ($product->sku)
                            <li><strong>Mã sản phẩm (SKU):</strong> <a href="#">{{$product->sku}}</a></li>
                            @endif
                            @if ($product->category && $tree = $product->category->getTree())
                                <li>Danh mục:
                                    @foreach ($tree as $cate)
                                    <a href="{{$cate->getViewUrl()}}">{{$cate->name}}</a>  
                                    @endforeach                                                
                                </li>
                            @endif
                            @if ($product->tags && count($product->tags))
                                <li class="tags">Thẻ:
                                    @foreach ($product->tags as $tag)
                                        <a href="{{route('client.products', ['s' => $tag->keyword])}}">{{$tag->name}}</a> 
                                    @endforeach
                                </li>
                            @endif
                        </ul>
                        @include($_template.'share', [
                            'link' => $product->getViewUrl(),
                            'title' => $product->name,
                            'description' => $product->getShortDesc(300),
                            'image' => $product->getFeatureImage()
                            
                        ])
                    </div>
                </div>
            </div>
        </div>
    </div>
</section><!--Shop Section-->

<section class="product-description bg-grey padding">
    <div class="container">
        <ul class="nav tab-navigation" id="product-tab-navigation" role="tablist">
            <li role="presentation">
                <button class="active" id="home-tab" data-bs-toggle="tab" data-bs-target="#home" type="button" role="tab" aria-controls="home" aria-selected="true">Chi tiết</button>
            </li>
            <li role="presentation">
                <button id="profile-tab" data-bs-toggle="tab" data-bs-target="#profile" type="button" role="tab" aria-controls="profile" aria-selected="false">Thông tin thêm</button>
            </li>
            <li role="presentation">
                <button id="contact-tab" data-bs-toggle="tab" data-bs-target="#contact" type="button" role="tab" aria-controls="contact" aria-selected="false">Đánh giá {{$reviews->total?"($reviews->total)":''}}</button>
            </li>
        </ul>
        <div class="tab-content" id="product-tab-content">
            <div class="tab-pane fade show active description" id="home" role="tabpanel" aria-labelledby="home-tab">
                {!! $product->detail !!}
                @if (is_array($specification = $product->specification) && $specification)
                    
                    @foreach ($specification as $item)
                        <div class="mt-15">
                            <h4>{{$item['name']}}</h4>
                            <ul class="description-meta">
                                @if (is_array($attrList = $item['list']))
                                    @foreach ($item['list'] as $attr)
                                        <li><span>{{$attr['key']}}:</span> {{$attr['value']}}</li>
                                    @endforeach
                                @endif
                            </ul>
                        </div>
                    @endforeach
                
            @endif

            </div>
            <div class="tab-pane ad-info fade" id="profile" role="tabpanel" aria-labelledby="profile-tab">
                @if ($attributes = $product->getProductAttributes())
                    
                    <table class="table product-table">
                        <thead>
                            <tr>
                                <th colspan="2" class="product-attribute-title">Thông tin sản phẩm</th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach ($attributes as $attr)
                                
                            <tr>
                                <td>{{$attr->label?$attr->label:$attr->name}}: </td>
                                <td>
                                    
                                    @foreach ($attr->values as $val)
                                        {{$loop->index?', ':''}}{{$val->text}}
                                    @endforeach
                                
                                </td>
                            </tr>
                            @endforeach
                        </tbody>
                    </table>
                    
                @endif
            </div>
            <div class="tab-pane fade review" id="contact" role="tabpanel" aria-labelledby="contact-tab">
                @if (count($product->reviews))
                    <ul class="comment-list">
                        @foreach ($product->reviews as $review)
                            <li>
                                <div class="comment-thumb"><img src="{{theme_asset('img/comment-1.png')}}" alt="img"></div>
                                <div class="comment-text">
                                    <div class="comment-author">
                                        <h3><span>{{ $review->dateFormat('d/m/Y') }}</span>{{ $review->review_name }}</h3>
                                        <ul class="ratting">
                                            @for ($i = 0; $i < $review->rating; $i++)
                                                <li><i class="las la-star"></i></li>
                                            @endfor
                                        </ul>
                                    </div>
                                    <p>{{$review->comment}}</p>
                                </div>
                            </li>
                            
                            
                        @endforeach
                        </ul>
                @endif
            </div>
        </div>
    </div>
</section><!--Product Description-->



@endsection


