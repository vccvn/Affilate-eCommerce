@extends($_layout.'master')
@section('title', $page_title)


@section('container')
<section class="page-header search-header" >
    <div class="bg-shape white"></div>
    <div class="container">
        <div class="page-header-content">
            <h4>Tìm kiếm</h4>
            <div class="sidebar-widget">
                <form method="GET" action="{{route('client.search')}}" class="search-form">
                    <input type="text" name="s" class="form-control" placeholder="Tìm kiếm" value="{{$keywords}}">
                    <button class="search-btn" type="submit"><i class="fa fa-search"></i></button>
                </form>
            </div>
            <!--/.search-form-->

            <ul class="search-menu">
                @if (count($refs = $helper->getSearchRefOptions($r = strtolower($request->ref))))
                    @foreach ($refs as $ref => $text)
                    <li class="ref-item" @if ($loop->last) aria-current="page" @endif>
                        <a href="{{route('client.search', ['ref' => $ref, 's' => $keywords])}}" class="{{$ref == $r?'active':''}}">{{$text}}</a>
                    </li>
                    @endforeach
                @endif
            </ul>
        </div>
    </div>
</section>
<!--/.page-header-->
<section class="blog-section bg-grey padding">
    <div class="bg-shape white"></div>
    <div class="container">
        <div class="row blog-posts">
            <div class="col-lg-12 sm-padding">
                
                
                @if (count($results))
                    <div class="row grid-layout">
                        @php
                            $item_class = 'col-md-4 padding-15';
                        @endphp
                        @foreach ($results as $item)
                            <div class="{{$item_class}}">
                                <div class="post-card">
                                    <div class="post-thumb">
                                        <a href="{{ $u = $item->getViewUrl() }}"><img src="{{ $item->getThumbnail() }}" alt="{{ $item->title }}"></a>
                                        @if ($item->category)
                        
                                        <div class="category"><a href="{{$item->category->getViewUrl()}}">{{$item->category->name}}</a></div>
                                        @endif
                                    </div>
                                    <div class="post-content">
                                        <ul class="post-meta">
                                            <li><i class="far fa-calendar-alt"></i><a href="{{ $u }}#created">{{ $item->dateFormat('d/m/Y') }}</a></li>
                                            <li><i class="far fa-user"></i><a href="{{ $u }}#author">{{$item->author->name}}</a></li>
                                        </ul>
                                        <h3><a href="{{ $u }}" title="{{ $item->title }}">{{ $item->title }}</a></h3>
                                        <p>{{ $item->getShortDesc(120) }}</p>
                                        <a href="{{ $u }}" class="read-more">Chi tiết <i class="las la-long-arrow-alt-right"></i></a>
                                    </div>
                                </div>
                            </div>
                        @endforeach
                    </div>
                    {{$results->links($_template.'pagination')}}
                @else
                    <div class="alert alert-warning">Không có kết quả phù hợp</div>
                @endif


            </div><!--/. col-lg-12 -->
        </div>
    </div>
</section><!--/. blog-section -->


@endsection
