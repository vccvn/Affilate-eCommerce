

<section class="page-header breadcrumbs">
    <div class="bg-shape grey"></div>
    <div class="container">
        <div class="page-header-content">
            @if ($sub_title = isset($sub_title) && $sub_title ? $sub_title : $__env->yieldContent('breadcrumbs.sub_title'))
            <h4>{!! $sub_title !!}</h4>
            @endif
            @if ($_title = isset($title) && $title ? $title : $__env->yieldContent('breadcrumbs.title'))
            <h2>{!! $_title !!}</h2>
            @endif
            <ul class="breadcrumb-links">
                @if ($breadcrumbs = $helper->getBreadcrumbs())
                    @foreach ($breadcrumbs as $item)
                        @if ($loop->last)
                            <li><span>{{ $item->text }}</span></li>
                        @else
                        <li><a title="{{ $item->text }}" href="{{ $item->url }}">{{ $item->text }}</a></li>
                        @endif
        
                    @endforeach
                @endif
            </ul>
            
        </div>
    </div>
</section><!--/.page-header-->