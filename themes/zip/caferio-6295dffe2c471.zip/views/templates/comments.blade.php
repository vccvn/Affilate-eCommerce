<?php
$commentList = isset($comments) && is_countable($comments) ? $comments : [];
$refname = isset($ref) ? $ref : null;
$refid = isset($ref_id) ? $ref_id : 0;
$link = isset($url) ? $url : null;
$t = count($commentList);
if ($user = $helper->getCurrentAccount()) {
    $name = $user->name;
    $email = $user->email;
} else {
    $name = null;
    $email = null;
}
?>

@if ($t)
    
<div class="comments-area">
    <div class="comments-section">
        <h3 class="single-post-tittle">Bình luận <span></span></h3>
        @include($_template.'comment-list', [
            'comments' => $comments,
            'level' => 0
        ])


        
    </div>
</div> <!--/.comments-area -->


@endif

<div class="comment-respond">
    <h3 class="single-post-tittle">Để lại ý kiến của bạn... <span></span></h3>
    <form method="post" action="{{ route('client.comments.post') }}" data-ajax-url="{{ route('client.comments.ajax') }}" id="commentform" class="comment-form {{ parse_classname('comment-form') }}">
        @csrf
        <input type="hidden" name="parent_id" id="comment-reply-id">
        <input type="hidden" name="ref" value="{{ $refname }}">
        <input type="hidden" name="ref_id" value="{{ $refid }}">
        <div class="form-textarea">
            <span class="crazy-message-content">
                <textarea name="message" id="comment" class="comment-message-content message inp " placeholder="Viết nội dung bình luận..." required>{{ old('message') }}</textarea>
            </span>
        </div>
        <div class="form-inputs">
            <input type="url" id="url" name="author_website" class="inp" value="{{ old('author_website') }}" placeholder="Website" maxlength="191">
            <input type="text" id="comment_name" name="author_name" class="inp" value="{{ old('author_name', $name) }}" placeholder="Tên *" required>
            <input type="email" id="comment_email" name="author_email" class="inp" value="{{ old('author_email', $email) }}" placeholder="Email *" required='required'>
        </div>
        <div class="form-submit">
            <input id="submit" value="Đăng bình luận" type="submit">
        </div>
    </form>
</div>



