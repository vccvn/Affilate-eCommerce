
<?php
$title = $data->title;
$params = [
    '@sorttype' => $data->sorttype, 
    '@limit' => $data->product_number?$data->product_number:6, 
    '@with' => ['promoAvailable'], 
    '@withReviews' => true, 
    '@withOption' => true,
    '@withCategory' => true
];
if($data->category_id && $category = $helper->getProductCategory(['id'=> $data->category_id])){
    $params['@category'] = $category->id;
}
$categories = [];
$products = $helper->getProducts($params);
if(count($products)){
    foreach ($products as $p) {
        if($cate = $p->category){
            $categories[$cate->slug] = $cate->name;
        }
    }
}

?>


        
        <section class="food-menu bg-grey padding">
            <div class="container">
                <div class="heading-wrap">
                    <div class="section-heading mb-30">
                        <h4>{{$data->sub_title}}</h4>
                        <h2>{!! $data->title !!}</h2>
                        <p>{!! nl2br($data->description) !!}</p>
                    </div>
                    @if ($data->show_full_menu_url)
                        
                    <div>
                        <p>{!! nl2br($data->full_menu_description) !!}</p>
                        <a href="{{$data->full_menu_url}}" class="default-btn"><i class="fas fa-utensils"></i>{{$data->btn_text}} <span></span></a>
                    </div>
                    @endif
                    
                </div>
                <div class="nav-outside">
                  <div class="food-carousel swiper-container nav-visible">
                       <div class="swiper-wrapper">
                        @foreach ($products as $product)
                            @php
                                $hasPromo = $product->hasPromo();
                                
                            $reviews = $product->getReviewData();
                            $hasOption = $product->hasOption();
                            $u = $product->getViewUrl();
                            @endphp
                            <div class="swiper-slide">
                                <div class="product-item">
                                    @if ($hasPromo)
                                        
                                <div class="sale">-{{$product->getDownPercent()}}%</div>
                                
                                @endif
                                    <div class="product-thumb">
                                        <img src="{{$product->getThumbnail()}}" alt="food">
                                        <div><a href="{{$hasOption?$u:'javascript:void(0)'}}" class="order-btn {{$hasOption? 'product-quick-view '.parse_classname('product-quick-view'): parse_classname('add-to-cart')}}" data-product-id="{{$product->id}}" data-redirect="checkout">Đặt hàng</a></div>
                                    </div>
                                    <div class="food-info">
                                    <ul class="ratting">
                                        <li>{{$product->category->name}}</li>
                                        @if ($reviews->total)
                                            @php
                                                $rateAvgInt = $reviews->rating_int;
                                                
                                                $rateAvgFlloat = $reviews->rating_avg;
                                                
                                                // Danh gia trung binh
                                                
                                            @endphp
                                                {{-- lặp qua từ 0 den so sao --}}
                                                @for ($i = 0; $i < $rateAvgInt; $i++)

                                                <li><i class="las la-star"></i></li>

                                                @endfor
                                                {{-- nếu rate_avg > rate_int thì cộng thêm nữa sao --}}
                                                @if ($rateAvgFlloat > $rateAvgInt)
                                                <li><i class="las la-star-o"></i></li>
                                                @endif
                                        @endif
                                    </ul>
                                        <h3>{{$product->name}}</h3>
                                        <div class="price">
                                            <h4>
                                                Giá: <span>{{$product->priceFormat('final')}}</span> 
                                                @if ($hasPromo)
                                                    
                                                <span class="reguler">{{$product->priceFormat('list')}}</span>
                                                @endif
                                            </h4>
                                        </div>
                                    </div>
                                </div>
                            </div>

                        @endforeach
                        </div>
                        <div class="dl-slider-controls style-2">
                            <div class="dl-slider-button-prev"><i class="las la-arrow-left"></i></div>
                            <div class="dl-swiper-pagination"></div>
                            <div class="dl-slider-button-next"><i class="las la-arrow-right"></i></div>
                        </div>
                        <div class="carousel-preloader"><div class="dot-flashing"></div></div>
                   </div>
                </div>
            </div>
        </section><!--/.food-menu-->