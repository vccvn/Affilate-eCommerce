
@php
    $header = $options->theme->header;
    if($header && ($header->logo_light || $header->logo_dark)){
        $logo_light = $header->logo_light($siteinfo->logo(theme_asset('img/logo-light.png')));
        $logo_dark = $header->logo_dark($siteinfo->logo(theme_asset('img/logo-dark.png')));
        // $group->name lấy giá trị
        // $group->name("default") lấy giá trị nếu không có sẽ trả về giá trị mặc định truyền vảo
        
    }else{
        $logo_light = $siteinfo->logo(theme_asset('img/logo-light.png'));
        $logo_dark = $siteinfo->logo(theme_asset('img/logo-dark.png'));
    }

    $type = $header->style ? $header->style : $__env->yieldContent('header.style', 1);
@endphp




        <header class="header {{$type == 2 ? 'dark-text': ''}}">
            <div class="primary-header-one primary-header">
                <div class="container">
                    <div class="primary-header-inner">
                        <div class="header-logo">
                            <a href="{{route('home')}}">
                                @if ($type == 2)
                                <img class="light" src="{{$logo_dark}}" alt="{{$siteinfo->site_name}}"/>
                                @else
                                <img class="light" src="{{$logo_light}}" alt="{{$siteinfo->site_name}}"/>
                                @endif
                                <img class="dark" src="{{$logo_dark}}" alt="{{$siteinfo->site_name}}"/>
                            </a>
                        </div><!-- /.header-logo -->
                        <div class="header-menu-wrap">
                            {!! 
                                // các tham số 
                                // 1: Vị trí menu hoặc tham số lấy menu
                                // ví dụ string: 'primary' // lấy ra menu đứng đầu có vị trí là primary
                                // hoặc mảng tham số : ['id' => $menuID , ...]
                                // 2: số cấp
                                // 3: thuộc tính html của menu
                                $helper->getCustomMenu('primary', 3, [
                                    'class' => 'slider-menu'
                                ])
                                // thêm một action khi lặp qua từng menu item
                                ->addAction(function($item, $link, $sub){
                                    $item->removeClass();
                                    if($item->isActive()){
                                        $item->addClass('current-menu-item');
                                    }
                                    if($sub){
                                        $sub->removeClass();
                                    }
                                    
                                })
                            !!}
                        </div><!-- /.header-menu-wrap -->
                        <div class="header-right">
                            @if ($header->show_search_button)
                            <div class="search-icon dl-search-icon"><i class="las la-search"></i></div>
                            @endif
                            @if ($header->show_addon_button)
                                
                            <a class="header-btn" href="{{$header->addon_button_link('/')}}">{{$header->addon_button_text('Reservation')}}<span></span></a>
                            @endif
                            <!-- Burger menu -->
                            <div class="mobile-menu-icon">
                                <div class="burger-menu">
                                    <div class="line-menu line-half first-line"></div>
                                    <div class="line-menu"></div>
                                    <div class="line-menu line-half last-line"></div>
                                </div>
                            </div>
                        </div><!-- /.header-right -->
                    </div><!-- /.primary-header-one-inner -->
                </div>
            </div><!-- /.primary-header-one -->
        </header><!-- /.header-one -->

        @if ($header->show_search_button)
        <div id="popup-search-box">
            <div class="box-inner-wrap d-flex align-items-center">
                <form id="form" action="{{route('client.products')}}" method="get" role="search">
                    <input id="popup-search" type="text" name="s" placeholder="Nhập từ khóa..." />
                    <button id="popup-search-button" type="submit" name="submit"><i class="las la-search"></i></button>
                </form>
            </div>
        </div><!-- /#popup-search-box -->
        @endif
