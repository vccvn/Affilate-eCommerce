
    
    
		<link rel="shortcut icon" type="image/x-icon" href="{{$siteinfo->favicon?$siteinfo->favicon:theme_asset('img/favicon.png')}}">
        <link rel="preconnect" href="https://fonts.googleapis.com">
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
        <link href="https://fonts.googleapis.com/css2?family=Montserrat:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap" rel="stylesheet">
        <link rel="stylesheet" href="{{theme_asset('css/animate.min.css')}}">
        <link rel="stylesheet" href="{{theme_asset('css/bootstrap.min.css')}}">
        <link rel="stylesheet" href="{{theme_asset('css/fontawesome.min.css')}}">
        <link rel="stylesheet" href="{{theme_asset('css/line-awesome.min.css')}}">
        <link rel="stylesheet" href="{{theme_asset('css/food-icon.css')}}">
        <link rel="stylesheet" href="{{theme_asset('css/slider.css')}}">
        <link rel="stylesheet" href="{{theme_asset('css/venobox.css')}}">
        <link rel="stylesheet" href="{{theme_asset('css/slick.min.css')}}">
        <link rel="stylesheet" href="{{theme_asset('css/swiper.min.css')}}">
        <link rel="stylesheet" href="{{theme_asset('css/splitting-cells.css')}}">
        <link rel="stylesheet" href="{{theme_asset('css/splitting.css')}}">
        <link rel="stylesheet" href="{{theme_asset('css/keyframe-animation.css')}}">
        <link rel="stylesheet" href="{{theme_asset('css/header.css')}}">
        <link rel="stylesheet" href="{{theme_asset('css/blog.css')}}">
        <link rel="stylesheet" href="{{theme_asset('css/main.css')}}">
        <link rel="stylesheet" href="{{theme_asset('css/responsive.css')}}">
        
        @include($_lib.'css')
        
        <link rel="stylesheet" href="{{theme_asset('css/custom.css')}}">
        {{-- <link rel="stylesheet" href="{{theme_asset('libs/bs-datepicker/css/datepicker.css')}}"> --}}
        


        <script src="{{theme_asset('js/vendor/modernizr-2.8.3-respond-1.4.2.min.js')}}"></script>

        