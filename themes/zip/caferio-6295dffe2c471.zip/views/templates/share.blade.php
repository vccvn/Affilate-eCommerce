
<?php 
$url = urlencode(isset($link)?$link:route('home'));
$desc = urlencode(isset($description)?$description:'');
$img = urlencode(isset($image)?$image:'');
$tit = urlencode(isset($title)?$title:'');
$template = isset($template)?$template:1;
?>
<ul class="social-icon">
    <li>Chia sẻ:</li>
    <li><a href="https://www.facebook.com/sharer/sharer.php?u={{$url}}"><i class="lab la-facebook-f"></i></a></li>
    <li><a href="https://twitter.com/home?status={{$url}}{{$desc?' '.$desc:''}}"><i class="lab la-twitter"></i></a></li>
    <li><a href="#"><i class="lab la-behance"></i></a></li>
</ul>