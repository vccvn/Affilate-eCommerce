


    
                <!-- ========== BEGIN PARALLAX ========== -->                 
                <div id="parallax-section"> 
                    <div class="img-overlay1" style="background: url({{$data->background}}) center fixed; background-size: cover"> 
                        <div class="container"> 
                            <div class="caption text-center"> 
                                <div class="color-white text-center weight-300 medium-caption">{{$data->medium_caption}}</div>                                 
                                <div class="color-white text-center weight-800 large-caption">{{$data->large_caption}}</div>                                 
                                <div class="color-white text-center weight-400 medium-caption">{{$data->second_caption}}</div>                                 
                                <h5>{{$data->description}}</h5> 
                            </div>                             
                        </div>                         
                    </div>                     
                </div>                 
                <!-- ========== END PARALLAX ========== -->        