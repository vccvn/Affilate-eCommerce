<!--========== BEGIN .CALENDAR ==========-->
<div id='calendar' data-lang="{{$data->lang('vi')}}"></div>
<!--========== END .CALENDAR ==========-->