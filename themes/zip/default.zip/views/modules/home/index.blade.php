@extends($_layout.'master')
@include($_lib.'register-meta')
@section('content')         
    {!! $html->home->components !!}


@endsection