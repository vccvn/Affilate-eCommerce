                        <!-- Begin .outer -->                         
                        <div class="outer"> 
                            <div class="breaking-ribbon"> 
                                <h5>24h News On-Air</h5> 
                            </div>                             
                            <!-- Begin .newsticker -->                             
                            <div class="news-on-air"> 
                                <ul> 
                                    <li> 
                                        <h4><i class="fa fa-video-camera" aria-hidden="true"></i> <a href="#">Watch 24h News Streaming Live Online</a></h4> 
                                    </li>                                     
                                </ul>                                 
                                <div class="navi"> 
                                    <button class="up">
                                        <i class="fa fa-caret-left"></i>
                                    </button>                                     
                                    <button class="down">
                                        <i class="fa fa-caret-right"></i>
                                    </button>                                     
                                </div>                                 
                            </div>                             
                            <!-- End .outer -->                             
                        </div>                         
                        <!--========== END 24H NEWS ON-AIR ==========-->                         