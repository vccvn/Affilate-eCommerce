
     <!-- Favicon -->         
     <link rel="shortcut icon" href="{{$siteinfo->favicon?$siteinfo->favicon:theme_asset('img/favicon.png')}}" type="image/x-icon" /> 
     <!-- Web Fonts  -->         
     <link href="https://fonts.googleapis.com/css?family=Roboto+Condensed%7CRoboto+Slab:300,400,700%7CRoboto:300,400,500,700" rel="stylesheet"> 
     <!-- Stylesheets -->         
     <link rel="stylesheet" href="{{theme_asset('css/bootstrap.min.css')}}"> 
     <link rel="stylesheet" href="{{theme_asset('css/main.css')}}"> 
     <link rel="stylesheet" href="{{theme_asset('css/style.css')}}">
     <link rel="stylesheet" href="{{theme_asset('css/style-color.min.css')}}"> 
     <link rel="stylesheet" href="{{theme_asset('css/responsive.css')}}"> 
     <link rel="stylesheet" href="{{theme_asset('css/jquery-ui.min.css')}}"> 
     <link rel="stylesheet" href="{{theme_asset('css/weather-icons.min.css')}}"> 
     <link rel="stylesheet" href="{{theme_asset('css/customize.min.css')}}"> 
     <!--[if lt IE 9]>
        <script src="http://html5shiv.googlecode.com/svn/trunk/html5.js"></script>
    <![endif]-->         
     <link rel="stylesheet" href="//cdnjs.cloudflare.com/ajax/libs/font-awesome/4.6.3/css/font-awesome.min.css">
