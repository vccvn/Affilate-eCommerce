(function () {
  "use strict";

  var carousels = function () {
    $(".gtco-testimonials").each(function(i, e){
      var t = Number($(e).data('timeout'));

      if(!(t && !isNaN(t) && !isFinite(t) && t > 0)){
        t = 4000
      }else{
        t = t * 1000;
      }
      $(e).find(".owl-carousel1").owlCarousel({
        loop: true,
        center: true,
        margin: 0,
        responsiveClass: true,
        nav: false,
        autoplay: true,
        autoplayTimeout: t,
        autoplayHoverPause: true,
        responsive: {
          0: {
            items: 3,
            nav: false
          },
          680: {
            items: 3,
            nav: false,
            loop: false
          },
          1000: {
            items: 5,
            nav: true
          }
        }
      });
    });
  };

  (function ($) {
    carousels();
  })(jQuery);
})();