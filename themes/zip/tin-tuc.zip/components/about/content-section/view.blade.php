
@php
    $show = in_array($data->show_image_type, ['image', 'video']);
    $imgvid = '';
    if($show){
        if($data->show_image_type == 'image' && $data->image){
            $imgvid = '
            <div class="col-lg-6">
                <div class="content-img">
                    <img src="'.$data->image.'" alt="'.$siteinfo->site_name.'">
                </div>
            </div>
            ';
        }
        elseif ($data->show_image_type == 'video' && $data->video_url && $video = $helper->getVideoFromUrl($data->video_url)) {
            $imgvid = '
            <div class="col-lg-6">
                <div class="video-container">
                    <iframe width="560" height="315" src="'.$video->embed_url.'" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
                </div>
            </div>
            ';
        }
    }
@endphp

@if ($style = $data->mark_color && $data->mark_tags ? get_caferio_component_css($component->id, ['color' => $data->mark_color], $data->mark_tags) : false)
    <style>
        {!! $style !!}
    </style>
@endif
    <section class="content-section-2 padding {{$data->bg_color == 'grey' ? 'bg-grey': ''}} " @if ($data->bg_color == 'custom' && $data->bg_custom_color) style="background-color: {{$data->bg_custom_color}};" @endif id="caferio-component-{{$component->id}}">
        @if (in_array($data->shape_type, ['white', 'grey']))
            
        <div class="bg-shape {{$data->shape_type}}"></div>
        
        @endif
            <div class="container">
                <div class="row align-items-center">
                @if ($show && $data->image_side=='left')
                {!! $imgvid !!}
                @endif
                    <div class="col-lg-{{$show?6:12}}">
                        <div class="section-heading">
                            
                            @if ($data->sub_title)
                            <h4>{{ $data->sub_title }}</h4>
                            @endif
                            @if ($data->title)
                            <h3>{!! nl2br($data->title) !!}</h3>
                            @endif
                            
                            <p>{!!  nl2br($data->description) !!}</p>
                            @if ($data->sign)
                            <img class="sign" src="{{$data->sign}}" alt="sign">   
                            @endif
                                
                        </div>
                    </div>
                    @if ($show && $data->image_side!='left')
                    {!! $imgvid !!}

                    @endif
                </div>
            </div>
        </section><!--/.content-section-->