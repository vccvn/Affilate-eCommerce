@if ($data->video_url)
    @php
        $video = $helper->getVideoFromUrl($data->video_url);
        $thumbnail = $data->thumbnail($video->thumbnail);
    @endphp
@endif
        <section class="about-section inner padding {{$data->bg_color == 'grey' ? 'bg-grey': ''}} " @if ($data->bg_color == 'custom' && $data->bg_custom_color) style="background-color: {{$data->bg_custom_color}};" @endif>
            @if (in_array($data->shape_type, ['white', 'grey']))
                
            <div class="bg-shape {{$data->shape_type}}"></div>
            
            @endif
            <div class="container">
                <div class="row align-items-center">
                   <div class="col-md-6">
                       <div id="gallery-videos-demo" class="content-img-holder video-popup">
                          <img src="{{$thumbnaul}}" alt="{{strip_tags($data->title)}}">
                           <a class="play-btn" data-autoplay="true" data-vbtype="video" href="{{$data->video_url}}">
                                <span class="play-icon"><i class="fas fa-play"></i></span>
                            </a>
                       </div>
                   </div>
                    <div class="col-md-6">
                        <div class="about-info">
                            <h2 class="mb-20">{!!$data->title!!}</h2>
                            @if ($lines = nl2array($data->content))
                                @foreach ($lines as $line)
                                    <p>{{$line}}</p>
                                @endforeach
                            @endif
                            <a href="{{$data->url}}" class="default-btn">{{$data->btn_text('Đặt hàng')}} <span></span></a>
                        </div>
                    </div>
                </div>
            </div>
        </section><!--/.about-section-->
