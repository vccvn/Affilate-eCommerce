@php
    $logo = $data->logo?$data->logo:(
        $siteinfo->footer_logo?$siteinfo->footer_logo:(
            $siteinfo->logo?$siteinfo->logo:theme_asset('img/logo-dark.png')
        )
    );
@endphp
                        <div class="col-lg-{{$data->col_lg(3)}} col-sm-{{$data->col_sm(6)}} sm-padding">
                            <div class="footer-widget">
                                @if ($data->use_logo)
                                    <a class="logo" href="{{route('home')}}"><img src="{{$logo}}" alt="{{$siteinfo->site_info}}"></a>
                                @else
                                    <h3>{{$data->title}} <span></span></h3>
                                @endif
                                
                                <p>{{$data->about_content}}</p>

                                {!!
                                    $helper->getCustomMenu(['id' => $data->menu_id], 1, [
                                        'class' => $data->menu_type == 'social' ? 'footer-social' : $data->menu_class
                                    ])
                                !!}
                            </div>
                        </div>