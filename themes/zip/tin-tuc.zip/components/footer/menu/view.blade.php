
                        <div class="col-lg-{{$data->col_lg(2)}} col-sm-{{$data->col_sm(6)}} sm-padding">
                            <div class="footer-widget {{$data->ml_25?'ml-25':''}}">
                                <h3>{{$data->title}} <span></span></h3>
                                {!!
                                    $helper->getCustomMenu(['id' => $data->menu_id], 1, [
                                        'class' => $data->menu_class
                                    ])
                                !!}
                            </div>
                        </div>