
        <section class="about-section padding {{$data->bg_color == 'grey' ? 'bg-grey': ''}} " @if ($data->bg_color == 'custom' && $data->bg_custom_color) style="background-color: {{$data->bg_custom_color}};" @endif>
            @if (in_array($data->shape_type, ['white', 'grey']))
                
            <div class="bg-shape {{$data->shape_type}}"></div>
            
            @endif
            <div class="container">
                <div class="row align-items-center">
                   <div class="col-md-6 wow fadeInLeft" data-wow-delay="200ms">
                       <div class="content-img-holder">
                          <img src="{{$data->image(theme_asset('img/about01.png'))}}" alt="{{$data->title}}">
                          @if ($data->show_sale)
                              
                           <div class="sale">
                               <div>
                                   <h4>{{$data->sale_sub_title('Get Up To')}}</h4>
                                    <h2><span>{{$data->sale_info('50%')}}</span>{{$data->sale_addon_text('Off Now')}}</h2>
                                </div>
                            </div>

                            
                          @endif
                       </div>
                   </div>
                    <div class="col-md-6 wow fadeInRight" data-wow-delay="400ms">
                        <div class="about-info">
                            @if ($data->title)
                            <h2>{!! nl2br($data->title) !!}</h2>
                            @endif
                            
                            <p>{!!  nl2br($data->description) !!}</p>
                            <ul class="check-list">
                                @if ($feature_list = nl2array($data->features))
                                    @foreach ($feature_list as $item)
                                    <li><i class="fas fa-check"></i>{{$item}}</li>
                                    @endforeach
                                @endif
                            </ul>
                            <a href="{{$data->url}}" class="default-btn">{{$data->btn_text('Order Now')}} <span></span></a>
                        </div>
                    </div>
                </div>
            </div>
        </section><!--/.about-section-->
