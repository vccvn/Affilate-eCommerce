

<div class="col-md-{{$data->colunn_size}} wow fadeInUp" data-wow-delay="400ms">
    <div class="banner-item">
         <img src="{{$data->image}}" alt="banner">
         <div class="banner-content">
             <h3>{!! nl2br($data->title) !!}</h3>
            <p>{{$data->description}}</p>
            <a href="{{$data->url}}" class="default-btn">{{$data->btn_text('đặt hàng')}} <span></span></a>
         </div>
     </div>
</div>