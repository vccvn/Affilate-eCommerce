


        <section class="content-section ">
            <div class="bg-shape white"></div>
            <div class="bg-shape grey"></div>
            <div class="container">
                <div class="row align-items-center">
                    <div class="col-md-6 wow fadeInLeft" data-wow-delay="200ms">
                        <div class="content-info">
                            <h2>{!! nl2br($data->title) !!}</h2>
                            <p>{{$data->description}}</p>
                            <a href="{{$data->url}}" class="default-btn">{{$data->btn_text}} <span></span></a>
                        </div>
                    </div>
                    <div class="col-md-6 wow fadeInRight" data-wow-delay="400ms">
                        <div class="content-img-holder">
                            <img src="{{$data->image}}" alt="{{$siteinfo->site_name}}">
                            @if ($data->show_sale)
                              
                           <div class="sale">
                               <div>
                                   <h4>{{$data->sale_sub_title('Get Up To')}}</h4>
                                    <h2><span>{{$data->sale_info('50%')}}</span>{{$data->sale_addon_text('Off Now')}}</h2>
                                </div>
                            </div>

                            
                          @endif
                        </div>
                    </div>
                </div>
            </div>
        </section><!--/.content-section-->
