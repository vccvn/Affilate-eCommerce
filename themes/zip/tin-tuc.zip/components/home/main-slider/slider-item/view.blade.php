@if($background = $data->background)
@php
    add_css_link(theme_asset('banner/top/css/banner.min.css'));
    if($background = $data->background){
        $html->addCss("#caferio-top-banner-{$component->id}", [
            'background-image' => "url('{$background}')"
        ]);
    }
@endphp
                

            <div class="single-slide ">
                <div class="top-banner" id="#caferio-top-banner-{{$component->id}}">
                    <div class="banner-wrap">
                        <div class="container">
                            <div class="title-block">
                                <div class="tb-title-wrap">
                                    <h2 class="tb-title">
                                        {{$data->title}}
                                    </h2>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-12 col-md-6 l">
                                    <div class="mark-block">
                                        <h3 class="mark">
                                            {{$data->label}}
                                        </h3>
                                    </div>
                                    <p>
                                        {{$data->description}}
                                    </p>
                                    <div class="delivery">
                                        <img src="{{$data->delivery_image(theme_asset('banner/top/img/delivery.png'))}}" alt="{{$data->delivery_title($data->title)}}">
                                    </div>
                                </div>
                                <div class="col-12 col-md-6 r">
                                    <div class="food">
                                        <img src="{{$data->food_image(theme_asset('banner/top/img/food.png'))}}" alt="{{$data->food_title($data->title)}}">
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div><!--Slide-{{$data->index+1}}-->

@endif