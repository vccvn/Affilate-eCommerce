

<section class="promo-section padding {{$data->bg_color == 'grey' ? 'bg-grey': ''}} " @if ($data->bg_color == 'custom' && $data->bg_custom_color) style="background-color: {{$data->bg_custom_color}};" @endif>
    @if (in_array($data->shape_type, ['white', 'grey']))
        
    <div class="bg-shape {{$data->shape_type}}"></div>
    
    @endif
    <div class="container">
        <div class="nav-outside">
            <div class="food-carousel swiper-container nav-visible">
                <div class="swiper-wrapper">
                    @if ($data->list_type == "categories")
                        @php
                            $args = [
                                '@sorttype' => $data->sorttype,
                                '@limit' => $data->item_number > 0? $data->item_number : 5
                            ];
                            if($data->parent_category_id){
                                $args['parent_id'] = $data->parent_category_id;
                            }
                        @endphp
                        @if (count($categories = get_product_categories($args)))
                            @foreach ($categories as $cate)
                            <div class="swiper-slide">
                                <div class="food-item">
                                    <div class="food-icon">
                                        <i class="fi fi-pizza-slice"></i>
                                    </div>
                                    <div class="food-content">
                                        <h3>{{$cate->name}}</h3>
                                        <p>{{$cate->description}}</p>
                                    </div>
                                    <div class="food-thumb">
                                        <img src="{{$cate->getFeatureImage()}}" alt="{{$cate->name}}">
                                    </div>
                                </div>
                            </div>
        
                            @endforeach
                        @endif
                    @else
                        {!! $children !!}
                    @endif
                </div>
                <div class="dl-slider-controls style-2">
                    <div class="dl-slider-button-prev"><i class="las la-arrow-left"></i></div>
                    <div class="dl-swiper-pagination"></div>
                    <div class="dl-slider-button-next"><i class="las la-arrow-right"></i></div>
                </div>
                <div class="carousel-preloader">
                    <div class="dot-flashing"></div>
                </div>
            </div>
        </div>
    </div>
</section>
<!--/.promo-section-->

