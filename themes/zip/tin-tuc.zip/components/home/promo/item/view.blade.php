
@php
    $title = '';
    $description = '';
    $image = theme_asset('img/promo01.png');
    if($data->category_id && $category = get_product_category(['id' => $data->category_id])){
        $title = $category->name;
        $description = $category->description;
        $image = $category->getFeatureImage();
    }
    $title = $data->title($title);
    $description = $data->description($description);
    $image = $data->image($image);
@endphp

                    <div class="swiper-slide">
                        <div class="food-item">
                            <div class="food-icon">
                                <i class="{{$data->icon('fi fi-pizza-slice')}}"></i>
                            </div>
                            <div class="food-content">
                                <h3>{{$title}}</h3>
                                <p>{!! nl2br($description) !!}</p>
                            </div>
                            <div class="food-thumb">
                                <img src="{{$image}}" alt="{{$title}}">
                            </div>
                        </div>
                    </div>
