
        <section class="testimonial-section {{$data->bg_color == 'grey' ? 'bg-grey': ''}} padding" @if ($data->bg_color == 'custom' && $data->bg_custom_color) style="background-color: {{$data->bg_custom_color}};" @endif>
            @if (in_array($data->shape_type, ['white', 'grey']))
                
            <div class="bg-shape {{$data->shape_type}}"></div>
            
            @endif
             <div class="container">
                 <div class="section-heading mb-30 text-center wow fadeInUp" data-wow-delay="200ms">
                     <h4>{{$data->sub_title('Testimonials')}}</h4>
                     <h2>{!! nl2br($data->title) !!}</h2>
                     <p>{!! nl2br($data->description) !!}</p>
                 </div>
                 <div class="nav-outside">
                   <div class="testimonial-carousel swiper-container nav-visible">
                        <div class="swiper-wrapper">

                            @if ($data->list_type == 'data')
                                @if ($data->item_number > 0 && count($reviews = $helper->getProductReviews(['@sort' => $data->sort_type, '@limit' => $data->item_number])))
                                    @foreach ($reviews as $review)
                                        <div class="swiper-slide">
                                            <div class="testimonial-item">
                                                <div class="testi-thumb">
                                                    <img src="{{$review->getFeatureImage()}}" alt="{{$review->review_name}}">
                                                    <div class="author">
                                                        <h3>{{$review->review_name}}</h3>
                                                        <h4>Khách hàng</h4>
                                                    </div>
                                                </div>
                                                <p> "{{$review->comment}}"</p>
                                                <ul class="ratting">
                                                    @for ($i = 0; $i < $review->rating; $i++)
                                                        <li><i class="las la-star"></i></li>
                                                    @endfor
                                                </ul>
                                            </div>
                                        </div>
                                    @endforeach
                                @endif
                            @else
                                {!! $children !!}
                            @endif
                            

                         </div>
                         <div class="dl-slider-controls style-2">
                             <div class="dl-slider-button-prev"><i class="las la-arrow-left"></i></div>
                             <div class="dl-swiper-pagination"></div>
                             <div class="dl-slider-button-next"><i class="las la-arrow-right"></i></div>
                         </div>
                         <div class="carousel-preloader"><div class="dot-flashing"></div></div>
                    </div>
                 </div>
             </div>
         </section><!--/.testimonial-section-->