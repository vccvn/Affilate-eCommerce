
<div class="card-wrap">
    <div class="card text-center {{$data->only_avatar || $is_image_slides ?'card-image':''}}">
        @if ($data->only_avatar || $is_image_slides)
        <a class="img-popup" data-gall="gallery01" href="{{$data->avatar}}">
            <img class="full-image" src="{{$data->avatar}}" alt="{{$data->name}}">    
        </a>
        @else
        <img class="card-img{{$data->only_avatar || $is_image_slides ?'':'-top'}}" src="{{$data->avatar}}" alt="{{$data->name}}">
        
        <div class="card-body">
            <h5>{{$data->name}} <br />
            <span> {{$data->job}} </span>
            </h5>
            <p class="card-text">“ {{$data->comment}} ” </p>
        </div>
        @endif
        
    </div>
</div>
{{-- 
<ul class="ratting">
    @for ($i = 0; $i < $data->rating; $i++)
    <li><i class="las la-star"></i></li>
    @endfor
</ul> --}}