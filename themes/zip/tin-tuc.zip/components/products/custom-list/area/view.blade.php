@php
    $style = in_array($data->style, ['grid', 'slides'])?$data->style:'grid';

    if($children){
        $children->share(['show_info' => $data->show_info, 'style' => $style, 'thumbnail_size' => $data->thumbnail_size]);
    }
@endphp

@if ($style == 'slides')

        
<section class="food-menu {{$data->bg_color == 'grey' ? 'bg-grey': ''}} padding" @if ($data->bg_color == 'custom' && $data->bg_custom_color) style="background-color: {{$data->bg_custom_color}};" @endif>
    @if (in_array($data->shape_type, ['white', 'grey']))
        
    <div class="bg-shape {{$data->shape_type}}"></div>
    
    @endif
    <div class="container">
        <div class="section-heading mb-30 text-center wow fadeInUp" data-wow-delay="200ms">
            @if ($data->sub_title)
            <h4>{{ $data->sub_title }}</h4>
            @endif
            @if ($data->title)
            <h3>{!! nl2br($data->title) !!}</h3>
            @endif
            
            <p>{!!  nl2br($data->description) !!}</p>
        </div>
        <div class="nav-outside">
          <div class="food-carousel swiper-container nav-visible">
               <div class="swiper-wrapper">
                {!! $children !!}
                </div>
                <div class="dl-slider-controls style-2">
                    <div class="dl-slider-button-prev"><i class="las la-arrow-left"></i></div>
                    <div class="dl-swiper-pagination"></div>
                    <div class="dl-slider-button-next"><i class="las la-arrow-right"></i></div>
                </div>
                <div class="carousel-preloader"><div class="dot-flashing"></div></div>
           </div>
        </div>
    </div>
</section><!--/.food-menu-->


@else
<section class="custom-product-section {{$data->bg_color == 'grey' ? 'bg-grey': ''}} padding" @if ($data->bg_color == 'custom' && $data->bg_custom_color) style="background-color: {{$data->bg_custom_color}};" @endif>
    @if (in_array($data->shape_type, ['white', 'grey']))
        
    <div class="bg-shape {{$data->shape_type}}"></div>
    
    @endif
    <div class="container">
        <div class="section-heading mb-30 text-center wow fadeInUp" data-wow-delay="200ms">
            @if ($data->sub_title)
            <h4>{{ $data->sub_title }}</h4>
            @endif
            @if ($data->title)
            <h3>{!! nl2br($data->title) !!}</h3>
            @endif
            
            <p>{!!  nl2br($data->description) !!}</p>
        </div>
        <div class="row">
            {!! $children !!}
        </div>
    </div>
</section><!--/.custom-product-section-->
@endif
        
