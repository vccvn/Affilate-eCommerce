<?php
$keyword = $request->s??($request->search??($request->keyword??($request->timkiem??$request->tim)))
?>
<div class="sidebar-widget">
    <form method="GET" action="{{route('client.'.($data->search_scope == 'products' ?'products': 'search'))}}" class="search-form">
        <input type="text" name="s" class="form-control" placeholder="{{$data->placeholder('Tìm kiếm')}}" value="{{$keyword}}">
        <button class="search-btn" type="submit"><i class="fa fa-search"></i></button>
    </form>
</div><!--/.search-form-->
