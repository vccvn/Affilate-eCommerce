@extends($_layout.'master')

@section('container')
@include($_template.'breadcrumbs', [
    'sub_title' => 'Shopping Cart',
    'title' => "Giỏ hàng"
])



        
<section class="cart-section bg-grey padding">
    <div class="container">
        @if ($cart && $cart->details && count($cart->details))
            <div class="row cart-header">
                <div class="col-lg-6">Product</div>
                <div class="col-lg-3">Quantity</div>
                <div class="col-lg-1">Price</div>
                <div class="col-lg-1">Total</div>
                <div class="col-lg-1"></div>
            </div>
            @foreach ($cart->details as $item)
                <div class="row cart-body {{$loop->last?'':'pb-30'}} {{ parse_classname('cart-item', 'cart-item-' . $item->id) }}" id="cart-item-{{ $item->id }}">
                    <div class="col-lg-6">
                        <div class="cart-item">
                            <a href="{{ $item->link }}"><img src="{{ $item->image }}" alt="{{$item->product_name}}"></a>
                            <div class="cart-content">
                                <h3><a href="{{ $item->link }}" target="_blank">{{$item->product_name}}</a></h3>
                                @if ($item->attributes && count($item->attributes))
                                    <p>
                                        @foreach ($item->attributes as $i => $attr)
                                        <span>{{ $attr->label ?? $attr->name }}: <strong>{{ $attr->text }}</strong></span>
                                        @if (!$i)
                                            <br />
                                        @endif
                                        @endforeach
                                    </p>
                                @endif
                            </div>
                        </div>
                    </div>
                    <div class="col-4 col-lg-3">
                        <div class="cart-item">
                            <input class="{{ parse_classname('product-order-quantity', 'quantity', 'item-quantity') }}" data-item-id="{{ $item->id }}" type="number" name="quantity[{{$item->id}}]" min="1" step="1" value="{{ $item->quantity }}">
                        </div>
                    </div>
                    <div class="col-3 col-lg-1">
                        <div class="cart-item">
                            <p>{{ $item->getPriceFormat() }}</p>
                        </div>
                    </div>
                    <div class="col-3 col-lg-1">
                        <div class="cart-item">
                            <p><span class="{{ parse_classname('item-total-price') }}">{{ $item->getTotalFormat() }}</span></p>
                        </div>
                    </div>
                    <div class="col-2 col-lg-1">
                        <div class="cart-item">
                            <a class="remove {{parse_classname('remove-cart-item')}}" href="javascript:void(0)" data-item-id="{{$item->id}}"><i class="las la-times"></i></a>
                        </div>
                    </div>
                </div>




            @endforeach


            <div class="row">
                <div class="col-lg-6 offset-lg-6">
                    <ul class="cart-total mt-30">
                        <li><span>Tạm tính:</span> <i class="{{parse_classname('cart-sub-total-amount')}}">{{$helper->getCurrencyFormat($cart->sub_total)}}</i></li>
                        <li><span>Phí giao hàng:</span> <i>Miễn phí 150KM</i></li>
                        <li><span>Khuyến mải:</span> <strong class="{{parse_classname('cart-promo-amount')}}">{{$helper->getCurrencyFormat($cart->promo_total)}} </strong></li>
                        <li><span>Tổng tiền:</span> <strong class="{{parse_classname('cart-total-amount')}}">{{$helper->getCurrencyFormat($cart->total_money)}} </strong></li>
                        <li>
                            <a href="{{route("client.products")}}">Tiếp tục mua gọi món</a>
                            <a class="default-btn" href="{{route("client.orders.checkout")}}"><i class="fa fa-check"></i>Tiến hành thanh toán <span></span></a>
                        </li>
                    </ul>
                </div>
            </div>
        @else
            <div class="text-center">
                <h3>Không có sản phẩm nào trong giỏ hàng</h3>
            </div>
        @endif
    </div>
</section><!--/.cart-section-->

@endsection
