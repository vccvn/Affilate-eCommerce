@extends($_layout.'master')

@section('container')
@include($_template.'breadcrumbs', [
    'sub_title' => 'Quản lý đơn hàng',
    'title' => "Danh sách đơn hàng"
])

        
    <section class="cart-section bg-grey padding">
        <div class="container">
            
            <div class="row">
                
                <div class="col-lg-3 sm-padding">
                    <ul class="cart-total">
                        <li><a href="{{route('client.orders.manager')}}"  class="nav-link {{$key?'': 'active'}}">Tất cả đơn hàng</a></li>
                            
                        @foreach ($status_list as $item)
                            <li><a href="{{route('client.orders.list', ['status_key' => $status_keys[$item->key]])}}"  class="nav-link {{$key == $item->key ? "active":""}}">{{$item['label']}}</a></li>
                        @endforeach
                        <li><a href="{{route('client.customers.logout')}}">Thoát</a></li>
                        
                    </ul>


                </div>
                <div class="col-lg-9 sm-padding">
                    @if (count($orders))
                        <div class="row cart-header">
                            <div class="col-lg-1">Mã</div>
                            <div class="col-lg-2">Thời gian</div>
                            <div class="col-lg-3">Thanh toán</div>
                            <div class="col-lg-2">Giá trị</div>
                            <div class="col-lg-2">Trạng thái</div>
                            <div class="col-lg-2"></div>
                        </div>
                        @foreach ($orders as $order)
                            <div class="row cart-body {{$loop->last?'':'pb-30'}} {{parse_classname('order-item', 'order-item-'.$order->id)}}" id="{{'order-item-'.$order->id}}">
                                <div class="col-lg-1">{{$order->id}}</div>
                                <div class="col-lg-2">{{$order->dateFormat('d/m/Y')}}</div>
                                <div class="col-lg-3">{{$order->getPaymentMethodText()}}</div>
                                <div class="col-lg-2">{{$helper->getCurrencyFormat($order->total_money)}}</div>
                                <div class="col-lg-2">{{$order->getStatusLabel()}}</div>
                                <div class="col-lg-2">
                                    <a href="{{route('client.orders.detail', ['id' => $order->id])}}" class="btn btn-sm btn-danger">Chi tiết</a>
                                    @if ($order->canCancel())
                                    |
                                    <a href="#" class="{{parse_classname('btn-cancel-order')}} btn btn-sm btn-danger " data-id="{{$order->id}}">Hủy</a>
                                    @endif
                                </div>
                            </div>
                        @endforeach
    
                    @else
                        <div class="alert alert-warning text-center">
                            Không có đơn hàng nào!
                        </div>
                    @endif

                </div>

            </div>
        </div>
    </section><!--/.checkout-section-->

@endsection
