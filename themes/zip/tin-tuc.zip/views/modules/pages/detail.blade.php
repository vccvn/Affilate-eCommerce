@php
$postSettings = $options->theme->pages;
if (isset($parent)) {
    if ($dynamicSettings = get_caferio_page_settings($parent->id)) {
        $postSettings = $dynamicSettings;
        $postSettings->merge($dynamicSettings->all());
    }
    if ($parent != $article && ($pageSettings = get_caferio_page_settings($article->id))) {
        $postSettings->merge($pageSettings->all());
    }
} elseif ($pageSettings = get_caferio_page_settings($article->id)) {
    $postSettings->merge($pageSettings->all());
}

$postOptions = $postSettings->makeByPrefix('detail_');
$header_image = $postSettings->header_use_bg_image?(
    $article->id == $postSettings->page_id && $postSettings->detail_use_feature_image && $article->feature_image ? $article->getFeatureImage() : (
        $postSettings->header_bg_image($article->feature_image?$article->getFeatureImage():"")
    )
    
):"";
$sub_title = isset($parent) && $parent != $article?$parent->title:'';
$_title = $article->title;
$description = $article->description;
$layout = $postOptions->layout('sidebar');
$u = $article->getViewUrl();

@endphp

@extends($_layout.'page')
@section('page.layout', $layout)
@section('title', $page_title)
@include($_lib.'register-meta')
@section('header.style', $postSettings->header_style)
@if ($header_image)
    @section('header.background', $header_image)
@endif

@section('page.sub_title', $sub_title)
@section('page.title', $_title)
@section('page.description', $description)


@section('page.content')
    @if ($layout == 'page')
        
        @if ($postOptions->content_type == 'children')
        {!! get_caferio_page_component($article->id) !!}
        @elseif($postOptions->content_type=='children_before')
        {!! get_caferio_page_component($article->id) !!}
        {!! $article->content !!}
        @elseif($postOptions->content_type=='children_after')
        {!! $article->content !!}
        {!! get_caferio_page_component($article->id) !!}
        @else
        {!! $article->content !!}
        @endif

    @else
        <div class="row single-layout">
            <div class="col-lg-12 sm-padding">
                <div class="post-card">
                    @if ($postOptions->show_thumbnail)
                        
                    <div class="post-thumb">
                        <img src="{{$article->getImage()}}" alt="{{$article->title}}">
                        @if (isset($parent))
                            <div class="category"><a href="{{$parent->getViewUrl()}}">{{$parent->name}}</a></div>
                        @endif
                    </div>
                    
                    @endif
                    <div class="post-content">
{{--                         
                        <ul class="post-meta">
                        <li><i class="far fa-calendar-alt"></i><a href="{{$u}}#">{{$article->dateFormat('d-m-Y')}}</a></li>
                        <li><i class="far fa-user"></i><a href="{{$u}}#">{{$article->author->name}}</a></li>
                        <li><i class="far fa-comments"></i><a href="{{$u}}#comments">{{count($article->publishComments)}} Bình luận</a></li>
                        </ul>
                         --}}
                        <h3><a href="{{$u}}#">{{$article->title}}</a></h3>
                    
                        @if ($postOptions->content_type == 'children')
                            {!! get_caferio_page_component($article->id) !!}
                        @elseif($postOptions->content_type=='children_before')
                            {!! get_caferio_page_component($article->id) !!}
                            {!! $article->content !!}
                        @elseif($postOptions->content_type=='children_after')
                            {!! $article->content !!}
                            {!! get_caferio_page_component($article->id) !!}
                        @else
                            {!! $article->content !!}
                        @endif


                        @if(count($article->tags))
                            <div class="tags-group">
                                <ul class="tags">
                                    @foreach ($article->tags as $tag)
                                    <li>
                                        <a href="{{route('client.posts.tag', ['tag' => $tag->slug])}}">{{$tag->name}}</a>
                                    </li>
                                    @endforeach
                                        
                                </ul>
                                
                            </div>
                        @endif
                        {{-- <div class="author-box">
                            <img src="assets/img/comment-1.png" alt="img">
                            <div class="author-info">
                                <h4>S M Mostain Billah</h4>
                                <p>Wonderful serenity has taken possession of my entire soul, like these sweet mornings of spring which I enjoy with my whole heart. I am alone, and feel the charm of existence in this spot.</p>
                            </div>
                        </div> --}}
                        <!--/.author-box -->

                        
                    </div>
                </div>
            </div>
        </div>
        @if ($postOptions->show_comments)
                    
            @include($_template.'comments',[
                'comments' => $article->publishComments,
                'ref' => $article->type,
                'ref_id' => $article->id,
                'url' => $u
            ])
        @endif

        
    @endif


@endsection