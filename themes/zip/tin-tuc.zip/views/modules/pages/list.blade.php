@php
$postSettings = $options->theme->pages;
if (isset($parent)) {
    if ($dynamicSettings = get_caferio_page_settings($parent->id)) {
        $postSettings = $dynamicSettings;
        $postSettings->merge($dynamicSettings->all());
    }
    if ($parent != $article && ($pageSettings = get_caferio_page_settings($article->id))) {
        $postSettings->merge($pageSettings->all());
    }
} elseif ($pageSettings = get_caferio_page_settings($article->id)) {
    $postSettings->merge($pageSettings->all());
}

$postOptions = $postSettings->makeByPrefix('list_');
$header_image = $postSettings->header_use_bg_image?(
    $article->id == $postSettings->page_id && $postSettings->detail_use_feature_image && $article->feature_image ? $article->getFeatureImage() : (
        $postSettings->header_bg_image($article->feature_image?$article->getFeatureImage():"")
    )
    
):"";
$sub_title = isset($parent) && $parent != $article?$parent->title:'';
$_title = $article->title;
$description  = $article->description;
$layout = $postOptions->layout('sidebar');
if($postOptions->type!='classic') {
    $postOptions->type='grid';
    $row_class = 'grid-layout';
    $col_class = 'col-md-6 padding-15';

}else{
    $row_class = 'classic-layout';
    $col_class = 'col-lg-12 sm-padding';
    $layout = 'sidebar';
}
@endphp

@extends($_layout.'page')
@section('page.layout', $layout)
@section('title', $page_title)
@include($_lib.'register-meta')
@section('header.style', $postSettings->header_style)
@if ($header_image)
    @section('header.background', $header_image)
@endif

@section('page.sub_title', $sub_title)
@section('page.title', $_title)
@section('page.description', $description)


@section('page.content')

@if (count($pages))
    <div class="row {{$row_class}}">


        @foreach ($pages as $item)

            <div class="{{$col_class}}">
                <div class="post-card">
                    <div class="post-thumb">
                        <a href="{{ $u = $item->getViewUrl() }}"><img src="{{ $item->getThumbnail() }}" alt="{{ $item->title }}"></a>
                        @if (isset($parent) && $parent)
                            
                        <div class="category"><a href="{{$parent->getViewUrl()}}">{{$parent->title}}</a></div>
                        @endif
                    </div>
                    <div class="post-content">
                        <ul class="post-meta">
                        <li><i class="far fa-calendar-alt"></i><a href="{{ $u }}#created">{{ $item->dateFormat('d/m/Y') }}</a></li>
                        <li><i class="far fa-user"></i><a href="{{ $u }}#author">admin</a></li>
                        </ul>
                        <h3><a href="{{ $u }}" title="{{ $item->title }}">{{ $item->title }}</a></h3>
                        <p>{{ $item->getShortDesc(120) }}</p>
                        <a href="{{ $u }}" class="read-more">Chi tiết <i class="las la-long-arrow-alt-right"></i></a>
                    </div>
                </div>
            </div>
    
        @endforeach

        
    </div>


    {{ $pages->links($_template . 'pagination') }}
    @else
        <div class="alert">
            Danh sách trống
        </div>
    @endif

@endsection