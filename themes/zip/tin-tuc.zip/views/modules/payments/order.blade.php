@extends($_layout.'single')
{{-- @section('title', $account->formConfig->title) --}}
@include($_lib.'register-meta')

@section('content')


  
    <section class="main-container col1-layout">
        <div class="main container">
            <div class="page-content">
                <div class="account-login">
                    <div class="box-authentication">
                        <h4>{{ $page_title }}</h4>
                        <form class="form" action="{{ route('client.payments.check-order') }}" method="POST">
                            <div class="ps-form__content">
                                @csrf
                                @if ($error = session('error'))
                                    <div class="alert alert-danger text-center">
                                        {{ $error }}
                                    </div>
                                @endif
                        <label class="form__label" for="contact">
                            Email hoặc Số điện thoại <span class="required">*</span>
                        </label>
                        <input type="text" name="contact" id="contact" class="form-control" value="{{ old('contact') }}"
                            placeholder="Nhập email hoặc số diện thoại">
                        @if ($error = $errors->first('contact'))
                            <div class="alert alert-danger text-center">
                                {{ $error }}
                            </div>
                        @endif
                        <label class="form__label" for="order_id">
                            Mã đơn hàng <span class="required">*</span>
                        </label>
                        <input type="text" name="order_id" class="form-control" value="{{ old('order_id') }}"
                            placeholder="Mã đơn hàng">
                            @if ($error = $errors->first('email'))
                            <div class="alert alert-danger text-center">
                                {{ $error }}
                            </div>
                        @endif
                        <div class="form-group submit">
                            <button type="submit" class="button">Tiếp tục</button>
                        </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </section>








@endsection
