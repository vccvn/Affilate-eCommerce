@extends($_layout.'master')

@section('container')
@include($_template.'breadcrumbs', [
    'sub_title' => 'Thanh toán',
    'title' => "Thanh toán chuyển khoản"
])



<div class="ps-order-tracking">
    <div class="container">
        <div class="ps-section__header">
            <h3>{{$page_title}}</h3>
            <p></p>
        </div>
        <div class="ps-section__content">
            @if (!session('order_id'))
            <div class="ps-form--order-tracking bg-white">
                <form class="form" action="{{route('client.payments.check-order')}}" method="POST">
                    <div class="ps-form__content">
                        @csrf
                        @if ($error = session('error'))
                            <div class="alert alert-danger text-center">
                                {{$error}}
                            </div>
                        @endif
        
                        <div class="form-group">
                            <label class="form__label" for="contact">
                                Email hoặc Số điện thoại <span>*</span>
                            </label>
                            <input type="text" name="contact" id="contact" class="form-control" value="{{old('contact')}}" placeholder="Nhập email hoặc số diện thoại">
                        </div>
                        @if ($error = $errors->first('contact'))
                            <div class="alert alert-danger text-center">
                                {{$error}}
                            </div>
                        @endif
                        <div class="form-group">
                            <label class="form__label" for="order_id">
                                Mã đơn hàng <span>*</span>
                            </label>
                            <input type="text" name="order_id" class="form-control" value="{{old('order_id')}}" placeholder="Mã đơn hàng">
                        </div>
                        @if ($error = $errors->first('email'))
                            <div class="alert alert-danger text-center">
                                {{$error}}
                            </div>
                        @endif
                        <div class="form-group submit">
                            <button type="submit" class="ps-btn ps-btn--fullwidth">Tiếp tục</button>
                        </div>
                    </div>
                </form>

            </div>
            @else


            <div class="row">
                <div class="col-lg-6 mb-md--40">
                    <h3 class="heading-secondary mb-5">Thanh toán</h3>
                    <div class="login-reg-box bg-white">
                        <form action="{{route('client.payments.verify-transfer')}}" method="post" enctype="multipart/form-data">
                            <div class="ps-form__content">
                                @csrf
                                <input type="hidden" name="order_id" value="{{session('order_id')}}">
                                <div class="form-group">
                                    <label class="form__label" for="order_id">
                                        Mã đơn hàng <span>*</span>
                                    </label>
                                    <input type="text" name="order_id" class="form-control" value="{{session('order_id')}}" placeholder="Mã đơn hàng" readonly>
                                </div>
                                @if ($error = $errors->first('email'))
                                    <div class="alert alert-danger text-center">
                                        {{$error}}
                                    </div>
                                @endif
                                
                                <div class="form-group">
                                    <label for="billing_transaction_image" class="form__label">Biên lai <span>*</span></label>
                                    <div class="custom-file" style="height: 4.6rem;">
                                        <input type="file" name="image" id="billing_transaction_image" class="custom-file-input">
                                        <label class="custom-file-label" for="billing_transaction_image">Chưa có file nào dc chọn</label>
                                    </div>
                                    @if ($errors->has('image'))
                                        <div class="error has-error">{{$errors->first('image')}}</div>
                                    @endif
                                </div>
                                <div class="form-group">
                                    <label for="orderNotes" class="form__label">Ghi chú </label>
                                    <textarea class="form-control" id="orderNotes" name="note" placeholder="Ghi chú (Tùy chọn)">{{old('note')}}</textarea>
                                </div>
                                <div class="form-group submit">
                                    <button type="submit" class="button">Gửi</button>
                                </div>
                                
                            </div>
                            
                        </form>
                    </div>
                </div>
                <div class="col-lg-6 mb-md--40">
                    <h3 class="heading-secondary mb-5">Hướng dẫn</h3>
                    <div class=" bg-white" style="font-size: large">
                        @include($_lib.'payments.transfer')
                    </div>
                </div>
            </div>
        
        
        
            @endif
        </div>
    </div>
</div>


    


<div class="row">
    <div class="col-lg-6 mb-md--40 mx-auto">
        <h2 class="heading-secondary mb--30"></h2>
        <div class="login-reg-box bg--white">
            
        </div>
    </div>

</div>




@endsection