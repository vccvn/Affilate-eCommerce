@php
$settingData = get_caferio_post_setting_data($dynamic, isset($category)?$category:null);
$postSettings = $settingData['postSettings'];

$postOptions = $postSettings->makeByPrefix('detail_');
$layout = $postOptions->layout('sidebar');
if($postOptions->type!='classic') {
    $postOptions->type='grid';
    $row_class = 'grid-layout';
    $col_class = 'col-md-6 padding-15';

}else{
    $row_class = 'classic-layout';
    $col_class = 'col-lg-12 sm-padding';
    $layout = 'sidebar';
}

$u = $article->getViewUrl();


$settingData['sub_title'] = $dynamic->name;
$settingData['title'] = $article->title;
$settingData['description'] = $article->description;

@endphp

@extends($_layout.'blog')
@section('page.layout', $layout)
@section('title', $page_title)
@include($_lib.'register-meta')
@section('header.style', $postSettings->header_style)



@if ($settingData['header_image'])
    @section('header.background', $settingData['header_image'])
@endif
@section('page.sub_title', $settingData['sub_title'])
@section('page.title', $settingData['title'])
@section('page.description', $settingData['description'])


@section('page.content')
<div class="row single-layout">
    <div class="col-lg-12 sm-padding">
        <div class="post-card">
            <div class="post-thumb">
                <img src="{{$article->getImage()}}" alt="{{$article->title}}">
                @if ($article->category)
                    
                <div class="category"><a href="{{$article->category->getViewUrl()}}">{{$article->category->name}}</a></div>
                @endif
            </div>
            <div class="post-content">
                <ul class="post-meta">
                   <li><i class="far fa-calendar-alt"></i><a href="{{$u}}#">{{$article->dateFormat('d-m-Y')}}</a></li>
                   <li><i class="far fa-user"></i><a href="{{$u}}#">{{$article->author->name}}</a></li>
                   <li><i class="far fa-comments"></i><a href="{{$u}}#comments">{{count($article->publishComments)}} Bình luận</a></li>
                </ul>
                <h3><a href="{{$u}}#">{{$article->title}}</a></h3>
                {!! $article->content !!}
                @if(count($article->tags))
                <div class="tags-group">
                    <ul class="tags">
                        @foreach ($article->tags as $tag)
                        <li>
                            <a href="{{route('client.posts.tag', ['tag' => $tag->slug])}}">{{$tag->name}}</a>
                        </li>
                        @endforeach
                            
                    </ul>
                    
                </div>
                @endif
                {{-- <div class="author-box">
                    <img src="assets/img/comment-1.png" alt="img">
                    <div class="author-info">
                        <h4>S M Mostain Billah</h4>
                        <p>Wonderful serenity has taken possession of my entire soul, like these sweet mornings of spring which I enjoy with my whole heart. I am alone, and feel the charm of existence in this spot.</p>
                    </div>
                </div> --}}
                <!--/.author-box -->
                @php
                    $next = $article->next(true);
                    $previous = $article->previous(true);
                    
                @endphp
                @if ($next || $previous)
                    
                <div class="post-navigation">
                    @if ($previous)
                        
                    <div class="nav prev" style="background-image: url('{{$previous->getThumbnail()}}');">
                        <h4><a href="{{$previous->getViewUrl()}}"><span><i class="las la-arrow-left"></i>Previous</span>{{$previous->title}}</a></h4>
                    </div>
                    
                    @endif
                    @if ($next)
                    <div class="nav next" style="background-image: url('{{$next->getThumbnail()}}');">
                        <h4><a href="{{$next->getViewUrl()}}"><span>Next<i class="las la-arrow-right"></i></span>{{$next->title}}</a></h4>
                    </div>
                    @endif
                    
                </div><!--/.post-navigation -->
                
                @endif
            </div>
        </div>
    </div>
</div>
@if (!$postOptions->hide_comments)
            
    @include($_template.'comments',[
        'comments' => $article->publishComments,
        'ref' => $article->type,
        'ref_id' => $article->id,
        'url' => $u
    ])
@endif

@endsection