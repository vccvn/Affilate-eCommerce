@php
$settingData = get_caferio_post_setting_data($dynamic, isset($category)?$category:null);
$postSettings = $settingData['postSettings'];

$postOptions = $postSettings->makeByPrefix('list_');
$layout = $postOptions->layout('sidebar');
if($postOptions->type!='classic') {
    $postOptions->type='grid';
    $row_class = 'grid-layout';
    $col_class = 'col-md-6 padding-15';

}else{
    $row_class = 'classic-layout';
    $col_class = 'col-lg-12 sm-padding';
    $layout = 'sidebar';
}


@endphp

@extends($_layout.'blog')
@section('page.layout', $layout)
@section('title', $page_title)
@include($_lib.'register-meta')
@section('header.style', $postSettings->header_style)

    @if ($settingData['header_image'])
        @section('header.background', $settingData['header_image'])
    @endif
@section('page.sub_title', $settingData['sub_title'])
@section('page.title', $settingData['title'])
@section('page.description', $settingData['description'])


@section('page.content')



    <div class="alert">
        Danh sách trống
    </div>

@endsection