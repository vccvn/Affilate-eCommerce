@php
$settingData = get_caferio_post_setting_data($dynamic, isset($category)?$category:null);
$postSettings = $settingData['postSettings'];

$postOptions = $postSettings->makeByPrefix('list_');
$layout = $postOptions->layout('sidebar');
if($postOptions->type!='classic') {
    $postOptions->type='grid';
    $row_class = 'grid-layout';
    $col_class = 'col-md-6 padding-15';

}else{
    $row_class = 'classic-layout';
    $col_class = 'col-lg-12 sm-padding';
    $layout = 'sidebar';
}


@endphp

@extends($_layout.'blog')
@section('page.layout', $layout)
@section('title', $page_title)
@include($_lib.'register-meta')
@section('header.style', $postSettings->header_style)
@if ($settingData['header_image'])
    @section('header.background', $settingData['header_image'])
@endif

@section('page.sub_title', $settingData['sub_title'])
@section('page.title', $settingData['title'])
@section('page.description', $settingData['description'])
@section('blog.header', 'breadcrumbs')
@section('breadcrumbs.sub_title', $settingData['sub_title'])
@section('breadcrumbs.title', $settingData['title'])
@section('breadcrumbs.description', $settingData['description'])


@section('page.content')

@if (count($posts))
    <div class="row {{$row_class}}">


        @foreach ($posts as $item)

            <div class="{{$col_class}}">
                <div class="post-card">
                    <div class="post-thumb">
                        <a href="{{ $u = $item->getViewUrl() }}"><img src="{{ $item->getThumbnail() }}" alt="{{ $item->title }}"></a>
                        @if ($item->category)
                            
                        <div class="category"><a href="{{$item->category->getViewUrl()}}">{{$item->category->name}}</a></div>
                        @endif
                    </div>
                    <div class="post-content">
                        <ul class="post-meta">
                        <li><i class="far fa-calendar-alt"></i><a href="{{ $u }}#created">{{ $item->dateFormat('d/m/Y') }}</a></li>
                        <li><i class="far fa-user"></i><a href="{{ $u }}#author">{{$item->author->name}}</a></li>
                        </ul>
                        <h3><a href="{{ $u }}" title="{{ $item->title }}">{{ $item->title }}</a></h3>
                        <p>{{ $item->getShortDesc(120) }}</p>
                        <a href="{{ $u }}" class="read-more">Chi tiết <i class="las la-long-arrow-alt-right"></i></a>
                    </div>
                </div>
            </div>
    
        @endforeach

        
    </div>


    {{ $posts->links($_template . 'pagination') }}
    @else
        <div class="alert">
            Danh sách trống
        </div>
    @endif

@endsection