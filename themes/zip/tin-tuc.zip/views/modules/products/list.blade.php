@php
$settingData = get_caferio_product_setting_data(isset($category)?$category:null);
@endphp
@extends($_layout.'master')

@section('title', $page_title)
@include($_lib.'register-meta')
@section('header.style', 1)
@section('page.header.show', 1)
@section('page.sub_title', $settingData['sub_title'])
@section('page.title', $settingData['title'])
@section('page.description', $settingData['description'])
@if ($settingData['header_image'])
@section('header.background', $settingData['header_image'])
@endif


@section('container')

<section class="food-menu bg-grey padding">
    <div class="bg-shape white"></div>
    <div class="container">
        <div class="heading-wrap fixed">
            <div class="section-heading mb-30">


                {{-- <h4>Popular Dishes</h4>
                 <h2>Our Bestselling <span>Dishes</span></h2>
                 <p>Food is any substance consumed to provide nutritional <br> support for an organism.</p> --}}
                <?php

                    $url = $request->getRequestUri();
                    $attr_prefix = $helper->getAttributeRequestNamePrefix();
                ?>
                <form action="{{isset($category)?$category->getViewUrl():route('client.products')}}" method="get" class="product-sorter-form">

                    @if (strlen($request->category))
                    <input type="hidden" name="category" value="{{$request->category}}">
                    @endif
                    @if ($attr_data = $helper->getAttributeRequestData())
                    <?php $attr_prefix = $helper->getAttributeRequestNamePrefix(); ?>
                    @foreach ($attr_data as $name => $value)
                    @if (is_array($value))
                    @foreach ($value as $v)
                    <input type="hidden" name="{{$attr_prefix.$name}}[]" value="{{$v}}">
                    @endforeach
                    @else
                    <input type="hidden" name="{{$attr_prefix.$name}}" value="{{$value}}">
                    @endif

                    @endforeach
                    @endif
                    @if (strlen($request->min_price))
                    <input type="hidden" name="min_price" value="{{$request->min_price}}">
                    @endif
                    @if (strlen($request->max_price))
                    <input type="hidden" name="max_price" value="{{$request->max_price}}">
                    @endif
                    {!!
                    html_input([
                    'type' => 'select',
                    'name' => 'sortby',
                    'data' => get_product_sortby_data(),
                    'value' => $sortby,
                    'className' => 'form-select sortby',
                    'data-placeholder'=>"Sắp xếp"
                    ])
                    !!}
                </form>

            </div>
            <div class="text-right">

                <p>
                    @if ($t = count($products))
                    Hiển thị từ <strong>{{$products->from()}}</strong> đến <strong>{{$products->to()}}</strong> trên tổng số <strong>{{$products->total()}}</strong> sản phẩm
                    @else
                    Không tìm thấy sản phẩm nào
                    @endif

                </p>

            </div>
        </div>

        @if ($t)

        <div class="row">
            @foreach ($products as $product)
            @php
            $hasPromo = $product->hasPromo();
            $reviews = $product->getReviewData();
            $hasOption = $product->hasOption();
            $u = $product->getViewUrl();
            @endphp
            <div class="col-lg-4 col-sm-6 padding-15">
                <div class="product-item">
                    @if ($hasPromo)

                    <div class="sale">-{{$product->getDownPercent()}}%</div>

                    @endif
                    <div class="product-thumb">
                        <img src="{{$product->getThumbnail()}}" alt="{{$product->name}}">
                        <div><a href="{{$product->getViewUrl()}}" class="order-btn {{$hasOption? 'product-quick-view '.parse_classname('product-quick-view'): parse_classname('add-to-cart')}}" data-product-id="{{$product->id}}" data-redirect="checkout">Đặt hàng</a></div>
                    </div>
                    <div class="food-info">
                        <ul class="ratting">
                            <li>{{$product->category->name}}</li>
                            @if ($reviews->total)
                            @php
                            $rateAvgInt = $reviews->rating_int;

                            $rateAvgFlloat = $reviews->rating_avg;

                            // Danh gia trung binh

                            @endphp
                            {{-- lặp qua từ 0 den so sao --}}
                            @for ($i = 0; $i < $rateAvgInt; $i++) <li><i class="las la-star"></i></li>

                                @endfor
                                {{-- nếu rate_avg > rate_int thì cộng thêm nữa sao --}}
                                @if ($rateAvgFlloat > $rateAvgInt)
                                <li><i class="las la-star-o"></i></li>
                                @endif
                                @endif
                        </ul>
                        <h3><a href="{{$u}}">{{$product->name}}</a></h3>
                        <div class="price">
                            <h4>
                                Giá: <span>{{$product->priceFormat('final')}}</span>
                                @if ($hasPromo)

                                <span class="reguler">{{$product->priceFormat('list')}}</span>
                                @endif
                            </h4>
                        </div>
                    </div>
                </div>
            </div>


            @endforeach

        </div>

        {{$products->links($_template.'pagination')}}
        @else
        <div class="text-center alert alert-warning">
            Danh sách trống
        </div>
        @endif
    </div>
</section>
@endsection
