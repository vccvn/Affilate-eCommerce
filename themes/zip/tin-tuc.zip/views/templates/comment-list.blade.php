@php
    $level = isset($level)?$level:0;
    $comments = isset($comments)?$comments:[];
@endphp
@if (count($comments))
    <{{$level > 0?'ul':'ol'}} class="{{$level > 0? 'children' : 'comments'}}">
        @foreach ($comments as $comment)
            @php
                $isFirst = (!$level && !$loop->index);
                $avatar = $comment->author_id && ($author = get_model_data('user', $comment->author_id)) ? get_user_avatar($author->avatar) : asset('static/images/default/avatar.png');
            @endphp
            <li class="comment {{$isFirst?'even thread-even depth-1':''}}" @if ($isFirst) id="comment-1" @endif>
                <div @if ($isFirst) id="div-comment-1" @endif>
                    <div class="comment-thumb">
                        <div class="comment-img"><img src="{{$avatar}}" alt="{{$comment->author_name}}"></div>
                    </div>
                    <div class="comment-main-area">
                        <div class="comment-wrapper">
                            <div class="comments-meta">
                                <h4>{{$comment->author_name}} <span class="comments-date">{{$comment->dateFormat('d/m/Y - H:i')}}</span></h4>
                            </div>
                            <div class="comment-area">
                                <p>{{$comment->htmlMessage()}}</p>

                                @if ($level < 4)
                            
                                <div class="comments-reply">
                                    <a class="comment-reply-link btn-reply-comment" href="javascript:void(0);" data-id="{{ $comment->id }}" data-reply-for="{{ $comment->author_name }}"><span>Trả lời</span></a>
                                </div>
                                
                                @endif
                            </div>
                        </div>
                    </div>
                </div>
                @if ($comment->publishChildren && count($comment->publishChildren))
                    @include($_template.'comment-list', [
                        'comments' => $comment->publishChildren,
                        'level' => $level + 1
                    ])
                @endif

            </li>
        @endforeach
    </{{$level > 0?'ul':'ol'}}>
@endif