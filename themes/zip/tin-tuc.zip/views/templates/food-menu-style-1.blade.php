
<?php
$title = $data->title;
$params = [
    '@sorttype' => $data->sorttype, 
    '@limit' => $data->product_number?$data->product_number:6, 
    '@with' => ['promoAvailable'], 
    '@withReviews' => true, 
    '@withOption' => true,
    '@withCategory' => true
];
if($data->category_id && $category = $helper->getProductCategory(['id'=> $data->category_id])){
    $params['@category'] = $category->id;
}
$categories = [];
$products = $helper->getProducts($params);
if(count($products)){
    foreach ($products as $p) {
        if($cate = $p->category){
            $categories[$cate->slug] = $cate->name;
        }
    }
}

$col_lg = $data->col_lg(4);
$col_md = $data->col_md(6);

?>

        <section class="food-menu bg-grey padding">
            <div class="container">
                <div class="section-heading mb-30 text-center wow fadeInUp" data-wow-delay="200ms">
                    <h4>{{$data->sub_title}}</h4>
                    <h2>{!! $data->title !!}</h2>
                    <p>{!! nl2br($data->description) !!}</p>
                </div>
                @if (count($products))
                    
                <ul class="food-menu-filter">
                    <li class="active" data-filter="*">All</li>
                    @foreach ($categories as $slug => $name)
                    <li data-filter=".{{$slug}}">{{$name}}</li>    
                    @endforeach
                </ul>
                <div class="row product-items">
                    @foreach ($products as $product)
                        @php
                            $hasPromo = $product->hasPromo();
                            $reviews = $product->getReviewData();
                            $hasOption = $product->hasOption();
                            $u = $product->getViewUrl();
                        @endphp
                    <div class="col-lg-{{$col_lg}} col-md-{{$col_md}} padding-15 isotop-grid {{$product->category->slug}}">
                        <div class="product-item wow fadeInUp thumbnail-{{$data->thumbnail_size}}" data-wow-delay="200ms">
                            @if ($hasPromo)
                                
                           <div class="sale">-{{$product->getDownPercent()}}%</div>
                           
                           @endif
                            <div class="product-thumb">
                                <img src="{{$product->getThumbnail()}}" alt="{{$product->name}}">
                                <div><a href="{{$hasOption?$u:'javascript:void(0)'}}" class="order-btn {{$hasOption? 'product-quick-view '.parse_classname('product-quick-view'): parse_classname('add-to-cart')}}" data-product-id="{{$product->id}}" data-redirect="checkout">Đặt hàng</a></div>
                            </div>
                            <div class="food-info">
                               <ul class="ratting">
                                   <li>{{$product->category->name}}</li>
                                   @if ($reviews->total)
                                    @php
                                        $rateAvgInt = $reviews->rating_int;
                                        
                                        $rateAvgFlloat = $reviews->rating_avg;
                                        
                                        // Danh gia trung binh
                                        
                                    @endphp
                                        {{-- lặp qua từ 0 den so sao --}}
                                        @for ($i = 0; $i < $rateAvgInt; $i++)

                                        <li><i class="las la-star"></i></li>

                                        @endfor
                                        {{-- nếu rate_avg > rate_int thì cộng thêm nữa sao --}}
                                        @if ($rateAvgFlloat > $rateAvgInt)
                                            <li><i class="las la-star-o"></i></li>
                                        @endif
                                @endif
                               </ul>
                                <h3>{{$product->name}}</h3>
                                <div class="price">
                                    <h4>
                                        Giá: <span>{{$product->priceFormat('final')}}</span> 
                                        @if ($hasPromo)
                                            
                                        <span class="reguler">{{$product->priceFormat('list')}}</span>
                                        @endif
                                    </h4>
                                </div>
                            </div>
                        </div>
                    </div>

                    @endforeach
                </div
                
                @endif>
            </div>
        </section><!--/.food-menu-->