@php
    $footer = $options->theme->footer;

    $footerCss = [];
    if($footer->text_color){
        $html->addCss('.footer-section', [
            'color' => $footer->text_color
        ]);
    }
    if($footer->h_color){
        $html->addCss('.footer-section .footer-widget h3', [
            'color' => $footer->h_color
        ]);
    }
    
    if($footer->link_color){
        $html->addCss('.footer-section .contact-info-list li a, .footer-section .opening-hours-list li a:not(.default-btn)', [
            'color' => $footer->link_color
        ]);
    }
    
    if($footer->link_hover_color){
        $html->addCss('.footer-section .contact-info-list li a:not(.default-btn):hover', [
            'color' => $footer->link_hover_color
        ]);
    }
    
    if($footer->backgroud_type == 'image' && $footer->backgroud_image){
        $html->addCss('.footer-section', [
            'background' => "url('$footer->backgroud_image') no-repeat center center",
            'background-size' => 'cover'
        ]);
    }
    if($footer->backgroud_type == 'color' && $footer->backgroud_color){
        $html->addCss('.footer-section', [
            'background-color' => $footer->backgroud_color
        ]);
    }

    




@endphp



        <footer class="footer-section">
            <div class="footer-top">
                @if ($footer->show_illustration)
                    
                <div class="footer-illustration"></div>
                <div class="running-cycle"><div></div></div>
                
                @endif
                
                <div class="container">
                    <div class="row">
                        {!! $html->footer_widgets->components !!}


                    </div>
                </div>
            </div><!--/.footer-top -->
            @if ($footer->show_copyright)
                
            <div class="footer-bottom">
                <div class="container">
                    <div class="copyright-wrap">
                        @if ($footer->copyright_content)
                            {!! $footer->copyright_content !!}
                        @else
                        <p>© <span id="currentYear"></span> {{$siteinfo->site_name}} Giữ toàn quyền</p>
                        @endif
                        
                    </div>
                </div>
            </div><!--/.footer-bottom -->

            
            @endif
        </footer><!--/.footer-section -->
