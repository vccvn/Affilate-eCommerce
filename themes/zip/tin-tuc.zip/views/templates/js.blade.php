

		
		<script src="{{theme_asset('js/vendor/jquery-3.5.1.min.js')}}"></script>
		<script src="{{theme_asset('js/vendor/bootstrap.min.js')}}"></script>
		<script src="{{theme_asset('js/vendor/imagesloaded.pkgd.min.js')}}"></script>
		<script src="{{theme_asset('js/vendor/jquery.isotope.v3.0.2.js')}}"></script>
		<script src="{{theme_asset('js/vendor/splitting.min.js')}}"></script>
		<script src="{{theme_asset('js/vendor/slick.min.js')}}"></script>
		<script src="{{theme_asset('js/vendor/swiper.min.js')}}"></script>
		<script src="{{theme_asset('js/vendor/venobox.min.js')}}"></script>
		<script src="{{theme_asset('js/vendor/simpleParallax.min.js')}}"></script>
		<script src="{{theme_asset('js/vendor/smooth-scroll.js')}}"></script>
		<script src="{{theme_asset('js/vendor/waypoints.min.js')}}"></script>
		<script src="{{theme_asset('js/vendor/wow.min.js')}}"></script>
		{{-- <script src="{{theme_asset('libs/bs-datepicker/js/bootstrap-datepicker.js')}}"></script> --}}
        @include($_lib.'js')

        @yield('scripts')

		<script src="{{theme_asset('js/main.js')}}"></script>

		
<script>
    window.customCartInit = function() {
        App.cart.init({
            decimal: 0,
            templates: {
                item: '<li class="item even">' +
                    '<a href="{$link}" title="Product title here" class="product-image">' +
                    '<img src="{$image}" alt="{$name}"width="65"></a>' +
                    '<div class="product-details">' +
                    '<a href="javascript:void(0)" title="Remove This Item" class="remove-cart {{ parse_classname('remove-cart-item') }}" data-item-id="{$id}"><i class="pe-7s-trash"></i></a>' +
                    '<p class="product-name">' +
                    '<a href="{$link}">{$name}</a>' +
                    '</p>' +
                    '<strong>{$quantity}</strong> x <span class="price">{$price}</span>' +
                    '</div>' +
                    '</li>',
                attribute: '<p><strong class="{{ parse_classname('attribute-label') }}">{$label}</strong>: <span class="{{ parse_classname('attribute-value') }}">{$value}</span></p>'
            }
        });
    };
</script>
