<section class="page-header">
    <div class="bg-shape grey"></div>
    <div class="container">
        <div class="page-header-content">
            @if ($sub_title = $__env->yieldContent('page.sub_title'))
            <h4>{!! $sub_title !!}</h4>
            @endif
            @if ($_title = $__env->yieldContent('page.title'))
            <h2>{!! $_title !!}</h2>
            @endif
            
            @if ($_description = $__env->yieldContent('page.description'))
            <p>{!! $_description !!}</p>
            @endif
            
        </div>
    </div>
</section><!--/.page-header-->