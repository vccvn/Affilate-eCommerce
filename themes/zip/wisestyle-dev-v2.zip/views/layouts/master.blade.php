@php
    $html->addTagAttribute('html', 'lang', 'vi-VN');
    $html->addTagAttribute('body', [
        'class'=> "theme-color2 light ltr ". $__env->yieldContent('body.class')
    ]);
    $general = $options->theme->general;
    
@endphp
@extends($_lib.'layout')
@section('body')
    

    <!-- header start -->
    @include($_template.'header')
    <!-- header end -->

    <!-- mobile fix menu start -->
    @include($_template.'mobile-fix-menu')
    <!-- mobile fix menu end -->

    <!-- Breadcrumb section start -->
    @include($_template.'breadcrumb')
    <!-- Breadcrumb section end -->

    @yield('content')



    <!-- footer start -->
    @include($_template.'footer')
    <!-- footer end -->

    

@endsection
