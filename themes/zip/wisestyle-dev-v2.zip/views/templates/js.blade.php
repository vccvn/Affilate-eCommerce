
    <!-- theme Setting Start -->
    <div class="theme-setting">
        <ul>
            <li>
                <button id="darkButton" class="btn btn-sm dark-buttton">Dark</button>
            </li>
            <li>
                <button class="btn btn-sm rtl-button">RTL</button>
            </li>
            <li class="color-picker">
                <input type="color" class="form-control form-control-color" id="ColorPicker1" value="#e22454"
                    title="Choose your color">
            </li>
        </ul>
    </div>
    <!-- theme Setting End -->

    <!-- tap to top Section Start -->
    <div class="tap-to-top">
        <a href="#home">
            <i class="fas fa-chevron-up"></i>
        </a>
    </div>
    <!-- tap to top Section End -->

    <div class="bg-overlay"></div>

    <!-- latest jquery-->
    <script src="{{theme_asset('js/jquery-3.5.1.min.js')}}"></script>

    <!-- Bootstrap js -->
    <script src="{{theme_asset('js/bootstrap/bootstrap.bundle.min.js')}}"></script>

    <!-- feather icon js -->
    <script src="{{theme_asset('js/feather/feather.min.js')}}"></script>

    <!-- lazyload js -->
    <script src="{{theme_asset('js/lazysizes.min.js')}}"></script>

    <!-- Add To Home js -->
    <script src="{{theme_asset('js/pwa.js')}}"></script>

    <!-- Slick js -->
    <script src="{{theme_asset('js/slick/slick.js')}}"></script>
    <script src="{{theme_asset('js/slick/slick-animation.min.js')}}"></script>
    <script src="{{theme_asset('js/slick/custom_slick.js')}}"></script>

    <!-- notify js -->
    <script src="{{theme_asset('js/bootstrap/bootstrap-notify.min.js')}}"></script>

    <!-- script js -->
    <script src="{{theme_asset('js/theme-setting.js')}}"></script>
    <script src="{{theme_asset('js/script.js')}}"></script>
    <script src="{{theme_asset('js/home-script.js')}}"></script>