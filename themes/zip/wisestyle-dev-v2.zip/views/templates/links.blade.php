
    <link rel="preconnect" href="https://fonts.googleapis.com/" />
    <link rel="preconnect" href="https://fonts.gstatic.com/" crossorigin />
    <link rel="preconnect" href="https://fonts.googleapis.com/" />
    <link rel="preconnect" href="https://fonts.gstatic.com/" crossorigin />

    
    <link rel="shortcut icon" type="image/x-icon" href="{{$siteinfo->favicon?$siteinfo->favicon:theme_asset('images/favicon/2.png')}}">
    <!--Google font-->
    <link rel="preconnect" href="https://fonts.gstatic.com/">
    <link href="https://fonts.googleapis.com/css2?family=Rubik:wght@400;500;600;700&amp;display=swap" rel="stylesheet">

    <!-- bootstrap css -->
    <link id="rtl-link" rel="stylesheet" type="text/css" href="{{theme_asset('css/vendors/bootstrap.css')}}">

    <!-- font-awesome css -->
    <link rel="stylesheet" type="text/css" href="{{theme_asset('css/vendors/font-awesome.css')}}">

    <!-- feather icon css -->
    <link rel="stylesheet" type="text/css" href="{{theme_asset('css/vendors/feather-icon.css')}}">

    <!-- animation css -->
    <link rel="stylesheet" type="text/css" href="{{theme_asset('css/vendors/animate.css')}}">

    <!-- slick css -->
    <link rel="stylesheet" type="text/css" href="{{theme_asset('css/vendors/slick/slick.css')}}">
    <link rel="stylesheet" type="text/css" href="{{theme_asset('css/vendors/slick/slick-theme.css')}}">

    <!-- Theme css -->
    <link id="color-link" rel="stylesheet" type="text/css" href="{{theme_asset('css/demo2.css')}}">


    <link rel="stylesheet" href="{{theme_asset('css/custom.css')}}">